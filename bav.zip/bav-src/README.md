# BAV 🗣️ — apprendre à parler anglais

BAV (comme « bavarder ») est une application web gratuite pour apprendre l'anglais.
HTML, CSS et JavaScript purs : pas de framework, pas de build, pas de serveur.

**État : session 3 en cours — arbre des compétences et grammaire faits ; conversation et musique restent à faire.**

### Ce que la session 3 a ajouté (jusqu'ici)
- **Arbre des compétences** (`#/arbre`, `js/screens/tree.js`, `js/skills.js`, `js/treeLayout.js`, `js/camera.js`, `css/tree.css`, `data/skills.json`) : une carte de l'accueil l'ouvre ; carte SVG qu'on déplace/pince ; 5 branches = modules ; AUCUN texte sur la carte, tout est dans le panneau qui s'ouvre à droite (pourcentage, comment terminer, missions).
- **Grammaire** : `data/grammar.json` (8 mini-leçons, 48 questions), `js/screens/grammar.js` (cartes), `grammarLesson.js` (3 pages courtes), `grammarQuiz.js` (quiz corrigé).
- **Icône d'appli** : `manifest.webmanifest` + `assets/icons/` (écran d'accueil du téléphone).
- **Retour** : bande « ‹ » à gauche sur les menus de cartes ; pastille « Retour » en bas à gauche partout ailleurs.
- **Mots croisés / saisies** : clavier natif de l'appareil (l'ancien `js/keyboard.js` est supprimé).
- Toucher n'importe où sur une carte fait avancer.

### Ce que la session 2 a ajouté
- `js/storage.js` : toute la progression dans `localStorage` (clé `bav:data`, version 1).
- Test de placement au premier lancement (A1 / A2 / B1) : `js/screens/placement.js`.
- Vraies données sur l'accueil : série de jours, objectif du jour (4 missions), mot du jour.
- XP et paliers (`js/progress.js`) : mission 20 XP, répétition 5 XP, bonus précision jusqu'à +10, bonus série jusqu'à +5, palier n = 40 + 10 n XP, remise à zéro chaque lundi (heure de Paris).
- Flashcards à répétition espacée, boîtes de Leitner 1 à 5 (`js/srs.js`, `js/screens/flashcards.js`).
- Voix (`js/voice.js`) : meilleure voix anglaise disponible, mode lent, réécoute.
- Module **Jeux** : mots croisés, phrases à trous, phrase dans l'ordre, dictée audio, verbes irréguliers, chacun en 3 niveaux (`js/play.js` + `js/screens/*`).
- `data/vocabulary.json` : plus de 1000 mots, chacun avec sa phrase ; `data/irregular-verbs.json` : les verbes irréguliers.
- Textes en police Inter chargée depuis Google Fonts (repli sur la police du téléphone).
- Navigation : toucher une carte la fait GRANDIR jusqu'à devenir l'écran suivant (`js/slide.js`, `openCard`) ; « Retour » fait glisser l'écran sur le côté. Toutes les cartes sont cliquables. Plus de menu intermédiaire : une carte de jeu ouvre directement le jeu, et le niveau (Facile / Moyen / Défi) se règle dans le jeu (par défaut selon ton niveau d'anglais).
- Accueil réduit à 4 cartes : Salut (objectif + série, reprend ta dernière activité), Modules, Palier, Mot du jour.
- Fluidité des cartes 3D, micro-animation du logo, bouton pour changer le prénom.

> Les mentions de `data/demo.json` plus bas datent de la session 1 : ce fichier n'existe plus.

---

## 1. L'arborescence

```
bav/
├── index.html              La seule page : charge le CSS et le JavaScript
├── vercel.json             Réglages de mise en ligne (en-têtes, URL propres)
├── README.md               Ce guide
│
├── css/
│   ├── nav.css             Carte qui s'ouvre, glissements, en-tête des jeux (Retour + niveau)
│   ├── tokens.css          DESIGN SYSTÈME : couleurs, thème sombre, typo, espaces, animations
│   ├── base.css            Remise à zéro + styles de base du texte
│   ├── layout.css          Structure : barre du haut, contenu, navigation (bas / côté)
│   ├── components.css      Briques : logo, boutons, cartes, badges, progression, anneau, message flash
│   ├── deck.css            L'accueil : pile de cartes 3D (style éditorial)
│   ├── intro.css           Écran d'entrée : carte-badge 3D « Appuyer pour commencer »
│   └── screens.css         Styles du guide de style
│
├── js/
│   ├── main.js             Point d'entrée : monte l'appli, enregistre les écrans
│   ├── router.js           Affiche le bon écran selon l'adresse (#/grammaire…)
│   ├── slide.js            Transitions : carte qui s'ouvre (openCard) et glissement du Retour
│   ├── shell.js            Le cadre : barre du haut (logo = retour accueil, bouton couleurs), pas de menu en bas
│   ├── theme.js            Thème Auto / Clair / Sombre (mémorisé)
│   ├── theme-boot.js       Applique le thème avant l'affichage (pas de flash blanc)
│   ├── intro.js            Écran d'entrée (1re visite seulement) : carte-badge, son, déploiement de l'accueil
│   ├── sound.js            Sons fabriqués dans le navigateur (bip de badge, arpège), réglable dans le menu
│   ├── deck.js             Moteur des cartes 3D : le scroll fait tourner les cartes, la page reste fixe
│   ├── components.js       Briques en JS : progression, anneau, écran « bientôt », message flash
│   ├── icons.js            Toutes les icônes
│   ├── brand.js            Le logo (lettres BAV dessinées avec Styro)
│   ├── data.js             Lecture des fichiers JSON de /data
│   └── screens/
│       ├── home.js         Accueil : 6 cartes 3D (salut, objectif, série, modules, reprendre, mot du jour)
│       ├── moduleDeck.js   Écran de module en cartes 3D (missions factices)
│       ├── vocabulary.js   Écran Vocabulaire (cartes)
│       ├── grammar.js      Écran Grammaire (cartes)
│       ├── conversation.js Écran Conversation (cartes)
│       ├── music.js        Écran Musique (cartes)
│       └── design.js       Guide de style (#/design) : tout le design système au même endroit
│
├── data/
│   ├── modules.json        Les 4 modules : nom, icône, texte de l'écran vide, session prévue
│   └── demo.json           Données FACTICES de l'accueil (remplacées en session 2)
│
├── fonts/                  Licence de la police Inter (les textes la chargent depuis Google Fonts)
└── assets/                 Logo (logo.svg), icône (favicon.svg), licence de la typo Styro
```

**Règle d'or :** une fonctionnalité = un fichier dans `js/`. Les contenus (mots, leçons, chansons) vivront dans `data/` en JSON, jamais dans le code.

## 2. Le design

- **Couleurs** : 3 palettes de 5 couleurs (Glacier, Ocre, Lilas), choisies avec le bouton en haut à droite. Pour en ajouter une, copie un bloc `[data-palette="…"]` dans `css/tokens.css` et change les 5 codes, puis ajoute son nom dans `js/theme.js`.
- **Typographie** : **Styro uniquement pour le logo**. Tous les textes sont en **Inter**, classique et très lisible.
- **Accueil** : la page ne défile pas, ce sont les cartes qui tournent quand tu fais glisser le doigt. Les réglages de l'effet (angles, distance, vitesse) sont dans `js/deck.js`, fonction `pose()`.
- **Thème sombre** : automatique (suit ton téléphone) ou choisi avec le bouton rond en haut à droite.
- Pour voir tous les éléments (couleurs, boutons, cartes…) : ouvre `#/design`, par exemple `https://ton-site.vercel.app/#/design`.
- Pour changer une couleur ou une taille de texte, un seul fichier : `css/tokens.css`.

---

## 3. Mise en ligne, étape par étape (depuis ton téléphone)

Tu vas faire deux choses : mettre les fichiers sur **GitHub** (le coffre-fort du code), puis relier **Vercel** (qui publie le site). Ensuite, chaque modification sur GitHub met le site à jour toute seule.

### A. Préparer les fichiers

1. Télécharge le fichier **`bav.zip`** envoyé dans la conversation.
2. Décompresse-le (sur iPhone : appui long sur le fichier, « Décompresser » ; sur Android : appui sur le fichier, « Extraire »). Tu obtiens des fichiers et des dossiers.

### B. Créer le dépôt GitHub

1. Va sur **github.com** (navigateur du téléphone) et crée un compte gratuit si besoin.
2. Ouvre **github.com/new**.
3. *Repository name* : `bav`. Choisis **Public**. Ne coche rien d'autre. Appuie sur **Create repository**.

### C. Envoyer les fichiers (un dossier à la fois)

GitHub sur téléphone ne sait pas envoyer un dossier entier, donc on le fait dossier par dossier. Chaque dossier se crée en tapant son nom dans le nom d'un fichier.

**Les fichiers de la racine**
1. Sur la page du dépôt, appuie sur **uploading an existing file**.
2. Choisis `index.html`, `vercel.json` et `README.md` (3 fichiers, sélection multiple).
3. Appuie sur **Commit changes**.

**Chaque dossier : `css`, `js`, `js/screens`, `data`, `fonts`, `assets`**
1. **Add file → Create new file**.
2. Dans le nom du fichier, tape le dossier suivi d'une barre oblique et de `vide.txt`, par exemple `css/vide.txt`. Écris n'importe quoi dans le contenu (un point suffit) et valide avec **Commit changes**.
3. Ouvre le dossier qui vient d'apparaître (`css`), puis **Add file → Upload files**, et choisis **tous les fichiers** du dossier `css` de ton téléphone. **Commit changes**.
4. Recommence pour `js`, puis `js/screens`, `data`, `fonts`, `assets`.

> Les fichiers `vide.txt` sont inutiles : tu pourras les supprimer plus tard (ouvrir le fichier, trois points, *Delete file*). Ils ne gênent pas l'appli.

**Vérifie** : sur la page du dépôt, tu dois voir les dossiers `assets`, `css`, `data`, `fonts`, `js` et les fichiers `index.html`, `README.md`, `vercel.json`. Dans `js`, un dossier `screens`.

### D. Publier avec Vercel

1. Va sur **vercel.com** → **Sign Up** → **Continue with GitHub** (autorise l'accès).
2. **Add New… → Project**. Dans la liste, appuie sur **Import** à côté de `bav`.
3. Laisse **tout par défaut** : *Framework Preset* = **Other**, *Build Command* vide, *Output Directory* vide.
4. Appuie sur **Deploy**. Après environ 30 secondes, tu obtiens une adresse du type `https://bav-xxxx.vercel.app`.
5. Ouvre-la : BAV est en ligne.

### E. Mettre à jour plus tard

Chaque fois qu'un fichier du dépôt GitHub est modifié (en sessions 2 et 3, ou à la main), Vercel republie le site automatiquement en environ 30 secondes. Si l'ancienne version s'affiche, ferme complètement l'onglet puis rouvre l'adresse.

### F. Installer l'appli sur l'écran d'accueil (optionnel)

- iPhone (Safari) : bouton Partager → **Sur l'écran d'accueil**.
- Android (Chrome) : menu ⋮ → **Ajouter à l'écran d'accueil**.

---

## 4. Dépannage

| Problème | Solution |
|---|---|
| Page blanche | Vérifie que les dossiers `css`, `js`, `data`, `fonts` sont bien dans le dépôt avec les bons noms (minuscules). |
| Texte dans une autre police | Le dossier `fonts` est incomplet : il doit contenir 2 fichiers `Inter-….woff`. |
| « Un souci est survenu » | Le dossier `data` est incomplet ou absent. |
| Pas de changement après une modif | Attends 1 minute, puis ferme et rouvre l'onglet. |
| L'écran « Page introuvable » | L'adresse doit avoir la forme `…vercel.app/#/grammaire`. |

## 5. Licences

- **Styro** (logo) : © Indian Type Foundry, licence ITF FFL (`assets/LICENSE-Styro-FFL.txt`).
- **Inter** (textes) : SIL Open Font License 1.1 (`fonts/LICENSE-Inter-OFL.txt`).

## 6. Feuille de route

1. Interface (terminée)
2. Bases et vocabulaire (terminée)
3. Arbre + grammaire (faits) ← conversation et musique restent à faire
