// Caméra de l'arbre : déplacer la carte au doigt (avec inertie), pincer pour zoomer, voler en douceur vers un point.
// La « carte » est un groupe SVG (world) : on lui applique translate + scale à chaque image (pas de filtre coûteux).
//
//   const cam = createCamera({ svg, world, bounds: {w, h}, onTap(el, x, y) {…} });
//   cam.flyTo({ cx, cy, k }, { ms: 900, arc: 0.15 })   // promesse résolue à l'arrivée (false si interrompue)
//   cam.destroy();

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const easeInOut = (p) => (p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2);
export const easeOut = (p) => 1 - Math.pow(1 - p, 3);

export function createCamera({ svg, world, bounds, minK = 0.3, maxK = 2.4, onTap, onMove, onUserMove }) {
  let W = 1, H = 1;
  const cam = { cx: bounds.w / 2, cy: bounds.h / 2, k: 0.8 };
  let raf = 0;
  let tween = null;
  let inertia = 0;
  const pointers = new Map();
  let gesture = null;

  const measure = () => {
    const r = svg.getBoundingClientRect();
    W = r.width || 1;
    H = r.height || 1;
  };
  const apply = () => {
    const tx = W / 2 - cam.cx * cam.k;
    const ty = H / 2 - cam.cy * cam.k;
    world.setAttribute("transform", `translate(${tx.toFixed(2)} ${ty.toFixed(2)}) scale(${cam.k.toFixed(4)})`);
    onMove?.(cam, tx, ty);
  };
  const keepInside = () => {
    cam.k = clamp(cam.k, minK, maxK);
    cam.cx = clamp(cam.cx, 0, bounds.w);
    cam.cy = clamp(cam.cy, 0, bounds.h);
  };
  const toWorld = (sx, sy) => ({ x: (sx - (W / 2 - cam.cx * cam.k)) / cam.k, y: (sy - (H / 2 - cam.cy * cam.k)) / cam.k });
  const local = (e) => {
    const r = svg.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  function stop() {
    cancelAnimationFrame(raf);
    cancelAnimationFrame(inertia);
    if (tween) { const t = tween; tween = null; t.done(false); }
  }

  /** Vole vers { cx, cy, k }. arc : le zoom recule un peu au milieu du trajet (effet de caméra). */
  function flyTo(to, { ms = 900, arc = 0, ease = easeInOut } = {}) {
    stop();
    const from = { ...cam };
    const target = { cx: clamp(to.cx, 0, bounds.w), cy: clamp(to.cy, 0, bounds.h), k: clamp(to.k, minK, maxK) };
    const t0 = performance.now();
    return new Promise((resolve) => {
      tween = { done: resolve };
      const step = (now) => {
        const p = clamp((now - t0) / ms, 0, 1);
        const e = ease(p);
        cam.cx = from.cx + (target.cx - from.cx) * e;
        cam.cy = from.cy + (target.cy - from.cy) * e;
        cam.k = from.k * Math.pow(target.k / from.k, e) * (1 - arc * Math.sin(Math.PI * e));
        apply();
        if (p < 1) raf = requestAnimationFrame(step);
        else { tween = null; resolve(true); }
      };
      raf = requestAnimationFrame(step);
    });
  }

  function jumpTo(to) {
    stop();
    Object.assign(cam, to);
    keepInside();
    apply();
  }

  // ----- Doigts : déplacer, pincer -----
  const onDown = (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    stop();
    pointers.set(e.pointerId, local(e));
    if (pointers.size === 1) {
      const p = local(e);
      gesture = { x: p.x, y: p.y, t: performance.now(), moved: false, target: e.target.closest?.("[data-node]") || null, vx: 0, vy: 0, lx: p.x, ly: p.y, lt: performance.now() };
    } else if (pointers.size === 2) {
      const [a, b] = [...pointers.values()];
      gesture = { ...gesture, pinch: true, moved: true, d0: Math.hypot(a.x - b.x, a.y - b.y), k0: cam.k };
    }
  };
  const onMoveEv = (e) => {
    if (!pointers.has(e.pointerId) || !gesture) return;
    const p = local(e);
    const prev = pointers.get(e.pointerId);
    pointers.set(e.pointerId, p);
    if (pointers.size >= 2) {
      const [a, b] = [...pointers.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y) || 1;
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const before = toWorld(mid.x, mid.y);
      cam.k = clamp(gesture.k0 * (d / (gesture.d0 || 1)), minK, maxK);
      // le point sous les doigts reste sous les doigts
      cam.cx = before.x - (mid.x - W / 2) / cam.k;
      cam.cy = before.y - (mid.y - H / 2) / cam.k;
      keepInside();
      apply();
      onUserMove?.();
      return;
    }
    if (!gesture.moved && Math.hypot(p.x - gesture.x, p.y - gesture.y) > 7) {
      gesture.moved = true;
      try { svg.setPointerCapture(e.pointerId); } catch { /* rien */ }
    }
    if (!gesture.moved) return;
    const now = performance.now();
    cam.cx -= (p.x - prev.x) / cam.k;
    cam.cy -= (p.y - prev.y) / cam.k;
    keepInside();
    apply();
    onUserMove?.();
    const dt = Math.max(1, now - gesture.lt);
    gesture.vx = 0.8 * gesture.vx + 0.2 * ((p.x - gesture.lx) / dt);
    gesture.vy = 0.8 * gesture.vy + 0.2 * ((p.y - gesture.ly) / dt);
    gesture.lx = p.x; gesture.ly = p.y; gesture.lt = now;
  };
  const onUp = (e) => {
    if (!pointers.has(e.pointerId)) return;
    const g = gesture;
    pointers.delete(e.pointerId);
    if (pointers.size > 0) { gesture = { ...g, pinch: false }; return; }
    gesture = null;
    if (!g) return;
    if (!g.moved && performance.now() - g.t < 600 && e.type === "pointerup") { onTap?.(g.target, g.x, g.y); return; }
    if (g.pinch) return;
    // inertie : on continue sur la lancée, en ralentissant
    let vx = g.vx * 1000, vy = g.vy * 1000; // px/s
    if (Math.hypot(vx, vy) < 80) return;
    let last = performance.now();
    const glide = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      cam.cx -= (vx * dt) / cam.k;
      cam.cy -= (vy * dt) / cam.k;
      keepInside();
      apply();
      const f = Math.exp(-dt * 3.6);
      vx *= f; vy *= f;
      if (Math.hypot(vx, vy) > 14) inertia = requestAnimationFrame(glide);
    };
    inertia = requestAnimationFrame(glide);
  };
  const onWheel = (e) => {
    e.preventDefault();
    stop();
    const p = local(e);
    const before = toWorld(p.x, p.y);
    cam.k = clamp(cam.k * Math.exp(-e.deltaY * 0.0016), minK, maxK);
    cam.cx = before.x - (p.x - W / 2) / cam.k;
    cam.cy = before.y - (p.y - H / 2) / cam.k;
    keepInside();
    apply();
    onUserMove?.();
  };

  svg.addEventListener("pointerdown", onDown);
  svg.addEventListener("pointermove", onMoveEv);
  svg.addEventListener("pointerup", onUp);
  svg.addEventListener("pointercancel", onUp);
  svg.addEventListener("wheel", onWheel, { passive: false });
  const ro = new ResizeObserver(() => { measure(); apply(); });
  ro.observe(svg);
  measure();
  apply();

  return {
    cam,
    flyTo,
    jumpTo,
    stop,
    size: () => ({ W, H }),
    destroy() { stop(); ro.disconnect(); svg.removeEventListener("pointerdown", onDown); svg.removeEventListener("pointermove", onMoveEv); svg.removeEventListener("pointerup", onUp); svg.removeEventListener("pointercancel", onUp); svg.removeEventListener("wheel", onWheel); },
  };
}
