// Briques d'interface réutilisables (elles produisent du HTML, le style est dans css/components.css).

import { icon } from "./icons.js";
import { esc } from "./data.js";

/** Barre de progression. percent : 0 à 100. */
export function bar(percent, label = "Progression") {
  const p = Math.max(0, Math.min(100, Number(percent) || 0));
  return `<div class="bar" role="progressbar" aria-label="${esc(label)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p}">
    <span class="bar__fill" style="--p:${p}"></span></div>`;
}

/** Anneau de progression animé (ex. objectif du jour). */
export function ring({ done, goal, unit = "" }) {
  const r = 44;
  const circ = 2 * Math.PI * r;
  const ratio = Math.max(0, Math.min(1, done / goal));
  return `<div class="ring" role="img" aria-label="${done} sur ${goal} ${esc(unit)}">
    <svg viewBox="0 0 100 100" aria-hidden="true">
      <circle class="ring__track" cx="50" cy="50" r="${r}"/>
      <circle class="ring__value" cx="50" cy="50" r="${r}" style="--circ:${circ.toFixed(2)};--offset:${(circ * (1 - ratio)).toFixed(2)}"/>
    </svg>
    <div class="ring__label"><span>${done}/${goal}</span><small>${esc(unit)}</small></div>
  </div>`;
}

/** Écran « bientôt » d'un module (utilisé par les 4 écrans vides de la session 1). */
export function emptyState(mod) {
  const items = mod.coming.map((t) => `<li>${icon("sparkles")}<span>${esc(t)}</span></li>`).join("");
  return `
    <section class="empty mod-${mod.id}" aria-labelledby="empty-title">
      <p class="eyebrow">${esc(mod.label)}</p>
      <div class="empty__hero" style="margin-top:.75rem">
        <span class="icon-chip icon-chip--lg">${icon(mod.icon)}</span>
        <span class="badge badge--mod">${icon("clock")} Session ${mod.session} de la feuille de route</span>
        <h1 class="empty__title" id="empty-title">${esc(mod.headline)}</h1>
        <p class="empty__text">${esc(mod.text)}</p>
      </div>
      <div class="card card--flat" style="margin-top:1rem">
        <h2 class="section-title" style="margin:0 0 .75rem;font-size:var(--fs-h3)">Ce qui arrive ici</h2>
        <ul class="empty__list">${items}</ul>
      </div>
      <div class="empty__back"><a class="btn btn--secondary" href="#/">${icon("arrowLeft")} Retour à l'accueil</a></div>
    </section>`;
}

/** Petit message qui apparaît en bas puis disparaît. */
export function toast(message) {
  const zone = document.getElementById("toasts");
  if (!zone) return;
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = message;
  zone.append(el);
  setTimeout(() => {
    el.classList.add("is-leaving");
    el.addEventListener("animationend", () => el.remove(), { once: true });
  }, 2600);
}
