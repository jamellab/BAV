// Chargement des données JSON du dossier /data (avec mémoire pour ne pas recharger).

const cache = new Map();

export async function loadJSON(name) {
  if (!cache.has(name)) {
    const url = new URL(`../data/${name}`, import.meta.url);
    const promise = fetch(url).then((res) => {
      if (!res.ok) throw new Error(`Impossible de charger ${name} (${res.status})`);
      return res.json();
    });
    cache.set(name, promise);
    promise.catch(() => cache.delete(name)); // on pourra réessayer
  }
  return cache.get(name);
}

/** Protège le texte avant de l'insérer dans du HTML. */
export function esc(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}
