// Moteur « deck » : une pile de cartes en 3D pilotée par le défilement.
// La page ne bouge pas : une scène reste collée à l'écran (position: sticky) et le scroll
// ne fait que tourner les cartes sur leurs axes. Voir css/deck.css pour l'habillage.
//
// HTML attendu :
//   <div class="deck">
//     <div class="deck-track"><div class="deck-stage">
//        <div class="deck-cards"> <article class="slide">…</article> … </div>
//        <nav class="deck-index"></nav>
//     </div></div>
//   </div>

const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

/** Position 3D d'une carte selon son écart « d » avec la carte active (0 = au centre). */
function pose(d, h) {
  const ad = Math.abs(d);
  const s = Math.sign(d);
  const near = Math.min(ad, 1);
  const far = Math.max(ad - 1, 0);
  const c = clamp(d, -1.7, 1.7);

  const y = s * h * (0.80 * near + 0.58 * far);        // les voisines dépassent derrière la carte active
  const z = -Math.min(ad, 2.6) * 120;                  // elles reculent
  const rx = c * -34;                                   // basculent vers l'avant / l'arrière
  const ry = c * 30;                                    // tournent sur l'axe vertical
  const rz = c * -10;                                   // et s'inclinent
  const opacity = 1 - clamp((ad - 1.7) / 0.9, 0, 1);

  return {
    transform: `translate3d(0, ${y.toFixed(1)}px, ${z.toFixed(1)}px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg) rotateZ(${rz.toFixed(2)}deg)`,
    opacity: opacity.toFixed(3),
    veil: (Math.min(ad, 1.4) * 0.3).toFixed(3),
    z: Math.round(100 - ad * 10),
  };
}

/**
 * Active le deck dans `root`. Renvoie une fonction de nettoyage (à appeler quand on quitte l'écran).
 * @param {HTMLElement} root  élément .deck
 * @param {{ stepRatio?: number }} opts  stepRatio : hauteur de défilement par carte (fraction de l'écran)
 */
export function mountDeck(root, { stepRatio = 0.62 } = {}) {
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (reduced.matches) {
    root.classList.add("deck--flat"); // animations coupées : simple liste de cartes
    return () => {};
  }

  const track = root.querySelector(".deck-track");
  const stage = root.querySelector(".deck-stage");
  const cards = [...root.querySelectorAll(".slide")];
  const index = root.querySelector(".deck-index");
  const html = document.documentElement;
  const n = cards.length;

  let step = 500;
  let cardH = 400;
  let target = 0;   // position visée (en « cartes », ex. 2.4)
  let current = 0;  // position affichée (rattrape la cible en douceur)
  let raf = 0;
  const CYCLES = 5; // la pile est répétée 5 fois ; on saute de 1 tour quand on approche d'un bord → boucle sans fin
  const P = n * CYCLES;
  const snaps = [];
  for (let i = 0; i < P; i++) {
    const m = document.createElement("div");
    m.className = "deck-snap";
    track.prepend(m);
    snaps.push(m);
  }
  // distance circulaire entre la carte i et la position affichée (entre -n/2 et n/2)
  const wrapD = (i, cur) => {
    let d = (i - cur) % n;
    if (d > n / 2) d -= n;
    if (d < -n / 2) d += n;
    return d;
  };
  let spreadT = 1;  // 0 = cartes empilées au centre, 1 = pile déployée (animé après l'écran d'entrée)

  // ----- Boutons-repères sur le côté -----
  index.innerHTML = cards
    .map((c, i) => `<button type="button" class="deck-tick" aria-label="Carte ${i + 1} sur ${n}" data-i="${i}"></button>`)
    .join("");
  const ticks = [...index.children];
  const onIndexClick = (e) => {
    const b = e.target.closest("button");
    if (b) goTo(Number(b.dataset.i));
  };
  index.addEventListener("click", onIndexClick);

  // ----- Mise en page : calcule les tailles selon l'écran -----
  function layout() {
    const vh = html.clientHeight;
    const vw = html.clientWidth;
    const topbar = document.querySelector(".topbar");
    const topH = topbar ? topbar.offsetHeight : 0;

    const stageH = vh - topH;
    stage.style.top = `${topH}px`;
    stage.style.height = `${stageH}px`;

    // Cartes paysage, plus petites : comme sur la planche de référence
    const w = Math.min(stage.clientWidth * 0.8, 460);
    cardH = Math.round(Math.min(w / 1.45, stageH * 0.5));
    stage.style.setProperty("--card-w", `${Math.round(w)}px`);
    stage.style.setProperty("--card-h", `${cardH}px`);

    step = Math.round(vh * stepRatio);
    track.style.height = `${vh - topH + (P - 1) * step}px`; // scroll total = (P-1) * step (plusieurs tours : boucle infinie)

    html.style.scrollPaddingTop = `${topH}px`;
    snaps.forEach((m, i) => (m.style.top = `${i * step}px`));
    render();
  }

  // ----- Affichage d'une position -----
  // Perf : le voile est un vrai élément (on change son opacité directement, pas une variable CSS qui
  // forcerait un recalcul de tout le contenu de la carte) et on n'écrit un style que s'il a changé.
  const veils = cards.map((c) => {
    const v = document.createElement("i");
    v.className = "slide__veil";
    v.setAttribute("aria-hidden", "true");
    c.append(v);
    return v;
  });
  const last = cards.map(() => ({ t: "", o: "", z: -1, v: "", a: "", h: false }));
  const lastTick = [];

  function render() {
    for (let i = 0; i < n; i++) {
      const card = cards[i];
      const L = last[i];
      const raw = wrapD(i, current);
      const d = raw * spreadOf(i);
      const ad = Math.abs(d);
      if (ad > 2.62 && L.h) continue; // carte déjà cachée et loin : rien à faire
      const p = pose(d, cardH);
      const hide = Number(p.opacity) <= 0;
      if (hide) {
        if (!L.h) { card.style.visibility = "hidden"; L.h = true; }
        continue;
      }
      if (L.h) { card.style.visibility = "visible"; L.h = false; }
      if (L.t !== p.transform) { card.style.transform = p.transform; L.t = p.transform; }
      if (L.o !== p.opacity) { card.style.opacity = p.opacity; L.o = p.opacity; }
      const z = Math.round((100 - ad * 10) * 100 - i);
      if (L.z !== z) { card.style.zIndex = z; L.z = z; }
      if (L.v !== p.veil) { veils[i].style.opacity = p.veil; L.v = p.veil; }
      const act = Math.abs(raw) < 0.5 ? "true" : "false";
      if (L.a !== act) { card.dataset.active = act; L.a = act; }
    }
    for (let i = 0; i < n; i++) {
      const ad = Math.abs(wrapD(i, current));
      const k = (1 - clamp(ad, 0, 1)).toFixed(2);
      if (lastTick[i] !== k) {
        ticks[i].style.setProperty("--k", k);
        ticks[i].setAttribute("aria-current", ad < 0.5 ? "true" : "false");
        lastTick[i] = k;
      }
    }
  }

  // ----- Déploiement de la pile (après l'écran d'entrée) : les cartes sortent l'une après l'autre -----
  function spreadOf(i) {
    if (spreadT >= 1) return 1;
    const local = clamp(spreadT * (1 + 0.12 * (n - 1)) - i * 0.12, 0, 1);
    return 1 - Math.pow(1 - local, 3); // ralentit à l'arrivée
  }
  let deployRaf = 0;
  function deploy() {
    const t0 = performance.now();
    const dur = 1500;
    const run = (now) => {
      spreadT = clamp((now - t0) / dur, 0, 1);
      render();
      deployRaf = spreadT < 1 ? requestAnimationFrame(run) : 0;
    };
    deployRaf = requestAnimationFrame(run);
  }
  const waiting = document.documentElement.dataset.intro === "pending";
  if (waiting) {
    spreadT = 0;
    window.addEventListener("bav:enter", deploy, { once: true });
  }

  // ----- Boucle d'animation : la position affichée rattrape le scroll -----
  let lastT = 0;
  function tick(now) {
    const dt = Math.min(0.05, ((now || performance.now()) - (lastT || now || performance.now())) / 1000) || 0.016;
    lastT = now || performance.now();
    const diff = target - current;
    if (Math.abs(diff) < 0.002) {
      current = target;
      render();
      raf = 0;
      lastT = 0;
      return;
    }
    current += diff * (1 - Math.exp(-dt * 16)); // même douceur quel que soit le nombre d'images par seconde
    render();
    raf = requestAnimationFrame(tick);
  }
  let settleTimer = 0;
  let programmatic = false;
  // « Aimantation » douce : quand le doigt s'arrête, on se cale sur la carte la plus proche
  // (fait en JS : le scroll-snap du navigateur se battait avec la boucle infinie et saccadait).
  function settle() {
    if (programmatic) return;
    const base = Math.round(window.scrollY / step);
    const dest = base * step;
    if (Math.abs(window.scrollY - dest) > 2) window.scrollTo({ top: dest, behavior: "smooth" });
  }
  function onScroll() {
    // près d'un bord : on saute d'un tour entier (invisible, les cartes sont identiques)
    const pos = window.scrollY / step;
    if (pos < n * 0.8) shift(n);
    else if (pos > P - 1 - n * 0.8) shift(-n);
    target = window.scrollY / step;
    if (!raf) raf = requestAnimationFrame(tick);
    clearTimeout(settleTimer);
    settleTimer = setTimeout(settle, 140);
  }
  function shift(cards_) {
    window.scrollTo({ top: window.scrollY + cards_ * step, behavior: "instant" });
    current += cards_;
    target += cards_;
  }

  // va vers la carte i en prenant le chemin le plus court (en avant ou en arrière, à travers la boucle)
  function goTo(i) {
    const base = Math.round(window.scrollY / step);
    const delta = wrapD(i, base);
    window.scrollTo({ top: (base + delta) * step, behavior: "smooth" });
  }

  // Toucher une carte voisine la ramène au centre ; le clavier suit le focus
  const onCardClick = (e) => {
    const card = e.target.closest(".slide");
    if (card && card.dataset.active === "false") {
      e.preventDefault();
      e.stopPropagation();
      goTo(cards.indexOf(card));
    }
  };
  const onFocusIn = (e) => {
    const card = e.target.closest(".slide");
    if (card && card.dataset.active === "false") goTo(cards.indexOf(card));
  };
  stage.addEventListener("click", onCardClick, true);
  stage.addEventListener("focusin", onFocusIn);

  // Touches ↑ ↓ : carte précédente / suivante (si on n'est pas dans un champ)
  const onKey = (e) => {
    if (e.target.closest("input, textarea, select")) return;
    const base = Math.round(target);
    if (e.key === "ArrowDown" || e.key === "PageDown") { e.preventDefault(); window.scrollTo({ top: (base + 1) * step, behavior: "smooth" }); }
    if (e.key === "ArrowUp" || e.key === "PageUp") { e.preventDefault(); window.scrollTo({ top: (base - 1) * step, behavior: "smooth" }); }
  };

  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", layout);
  window.addEventListener("keydown", onKey);

  layout();
  window.scrollTo({ top: Math.floor(CYCLES / 2) * n * step, behavior: "instant" }); // on démarre au milieu : on peut tourner dans les deux sens
  target = current = window.scrollY / step;
  render();

  return function cleanup() {
    cancelAnimationFrame(raf);
    clearTimeout(settleTimer);
    cancelAnimationFrame(deployRaf);
    window.removeEventListener("bav:enter", deploy);
    window.removeEventListener("scroll", onScroll);
    window.removeEventListener("resize", layout);
    window.removeEventListener("keydown", onKey);
    html.style.scrollSnapType = "";
    html.style.scrollPaddingTop = "";
    veils.forEach((v) => v.remove());
    snaps.forEach((m) => m.remove());
  };
}
