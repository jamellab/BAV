// Icônes de l'appli (SVG intégrés : pas de fichier à charger).
// Usage : icon("home") renvoie le code SVG, la couleur suit le texte (currentColor).

const PATHS = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>',
  cards: '<rect x="3" y="7" width="14" height="14" rx="3"/><path d="M7 4h11a3 3 0 0 1 3 3v11"/>',
  pencil: '<path d="M4 20h4L19.5 8.5a2.8 2.8 0 0 0-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
  chat: '<path d="M20.5 12a8.5 7.5 0 0 1-12.2 6.7L3.8 20l1.3-4A8.5 7.5 0 1 1 20.5 12Z"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  flame: '<path d="M12 22a7 7 0 0 0 7-7c0-3.5-2-5.5-3.5-7.5-.5 1.5-1.5 2.5-2.7 3C13 7 12.5 4.5 10.5 2 10.5 6 5 9 5 15a7 7 0 0 0 7 7Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5Z"/>',
  auto: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18Z" fill="currentColor"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  arrowLeft: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  speaker: '<path d="M4 10v4h4l5 4V6L8 10H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/><path d="M19 6a8.5 8.5 0 0 1 0 12"/>',
  sparkles: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/><path d="M19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7L19 16Z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.4 0 2-.9 2-1.8 0-1.4-1.2-1.7-1.2-2.9 0-1 .8-1.8 1.9-1.8H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3Z"/><path d="M7.5 11h.01M10 7.5h.01M14.5 7.5h.01"/>',
  circle: '<circle cx="12" cy="12" r="8.5"/>',
  gamepad: '<path d="M7 8h10a5 5 0 0 1 5 5v1.5a2.5 2.5 0 0 1-4.3 1.7L16 14.5H8l-1.7 1.7A2.5 2.5 0 0 1 2 14.5V13a5 5 0 0 1 5-5Z"/><path d="M7.5 10.5v3M6 12h3"/><path d="M16 11h.01M18 13h.01"/>',
  snail: '<path d="M3 18h15a3 3 0 0 0 0-6"/><circle cx="12" cy="9.5" r="4"/><circle cx="12" cy="9.5" r="1.2"/><path d="M3 18V14M21 12l1.5-3M19.5 11.5 20 8"/>',
  play: '<path d="M7 4.5v15l12-7.5-12-7.5Z"/>',
  grid: '<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M9 3v18M15 3v18M3 9h18M3 15h18"/>',
};

export function icon(name, { filled = false } = {}) {
  const body = PATHS[name] ?? PATHS.circle;
  return `<svg viewBox="0 0 24 24" fill="${filled ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2.2" stroke-linecap="square" stroke-linejoin="miter" aria-hidden="true" focusable="false">${body}</svg>`;
}

/** Icône « éventail de nuanciers » du bouton couleurs : trois échantillons qui prennent les couleurs de la palette en cours. */
export function swatchFan() {
  return `<svg class="fan" viewBox="0 0 32 30" aria-hidden="true" focusable="false">
    <rect class="fan__a" x="11" y="3" width="10" height="23" rx="2.6"/>
    <rect class="fan__b" x="11" y="3" width="10" height="23" rx="2.6"/>
    <rect class="fan__c" x="11" y="3" width="10" height="23" rx="2.6"/>
    <circle cx="16" cy="24" r="1.6" class="fan__pin"/>
  </svg>`;
}

/**
 * Petites illustrations géométriques des cartes de missions (traits francs, couleur d'accent de la carte).
 * Chaque motif est dessiné pour le jeu qu'il représente (pas des icônes génériques).
 */
const GLYPHS = {
  cards: '<rect x="14" y="10" width="34" height="42" /><path d="M20 4h36v42" /><path d="M22 24h18M22 32h12M22 40h16" />',
  blank: '<path d="M6 18h52M6 46h52" /><path d="M6 32h14M44 32h14" /><rect x="24" y="24" width="16" height="16" stroke-dasharray="4 3" />',
  crossword: '<rect x="6" y="6" width="52" height="52" /><path d="M23 6v52M40 6v52M6 23h52M6 40h52" /><path d="M6 6h17v17H6Z M40 40h18v18H40Z M23 23h17v17H23Z" fill="currentColor" stroke="none" opacity=".9" />',
  order: '<rect x="4" y="38" width="16" height="18" /><rect x="24" y="24" width="16" height="32" /><rect x="44" y="8" width="16" height="48" /><path d="M8 30l6-8 6 8" />',
  waves: '<path d="M8 28v8M18 18v28M28 8v48M38 14v36M48 22v20M58 28v8" stroke-width="5" />',
  lesson: '<path d="M8 10h34M8 22h26M8 34h30" /><path d="M38 44l6 6 12-14" stroke-width="4" /><rect x="4" y="4" width="46" height="50" />',
  verbs: '<circle cx="10" cy="32" r="6" /><circle cx="32" cy="32" r="6" /><circle cx="54" cy="32" r="6" fill="currentColor" /><path d="M17 32h8M39 32h8M22 27l4 5-4 5M44 27l4 5-4 5" />',
};

export function glyph(name) {
  const body = GLYPHS[name] ?? GLYPHS.cards;
  return `<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="square" stroke-linejoin="miter" aria-hidden="true" focusable="false">${body}</svg>`;
}

/** Corps d'une icône ou d'un motif, pour les insérer dans un autre SVG (arbre des compétences). */
export function symbol(name) {
  if (GLYPHS[name]) return { vb: 64, sw: 3, body: GLYPHS[name] };
  return { vb: 24, sw: 2.2, body: PATHS[name] ?? PATHS.circle };
}
