// Écran d'entrée : une carte-badge arrive de loin, pivote en 3D et se pose.
// L'appli reste fermée tant qu'on n'a pas touché l'écran. Au toucher : son, la carte glisse
// dans la pile et l'accueil se déploie (voir js/deck.js, événement « bav:enter »).
// Affiché à chaque ouverture de l'appli.

import { logoSVG } from "./brand.js";
import { playEnter } from "./sound.js";
import { getName, setName } from "./profile.js";

const KEY = "bav:intro-done";

export function introNeeded() {
  return true; // à chaque ouverture de l'appli (avant : seulement la 1re visite, clé "bav:intro-done")
}

export function mountIntro() {
  const html = document.documentElement;
  html.dataset.intro = "pending"; // le deck attend le signal avant de se déployer
  html.classList.add("intro-lock");

  const el = document.createElement("button");
  el.className = "intro";
  el.type = "button";
  el.setAttribute("aria-label", "Appuyer pour commencer");
  el.innerHTML = `
    <span class="intro__stage" aria-hidden="true">
      <span class="intro__card">
        <span class="intro__tilt">
          <span class="intro__hole"></span>
          <span class="intro__meta"><span>BAV — Pass</span><span>EN / FR</span></span>
          <span class="intro__logo">${logoSVG({ label: "" })}</span>
          <span class="intro__foot"><span>N° 001 — Bienvenue</span><span class="intro__bars"></span></span>
        </span>
      </span>
    </span>
    <span class="intro__cta">Appuyer pour commencer</span>`;
  document.body.append(el);
  el.focus({ preventScroll: true });

  let entered = false;
  function finish() {
    if (entered) return;
    entered = true;
    playEnter(); // doit être appelé pendant un toucher
    el.classList.add("is-leaving");
    window.dispatchEvent(new Event("bav:enter")); // l'accueil se déploie
    html.dataset.intro = "done";
    setTimeout(() => {
      html.classList.remove("intro-lock");
      el.remove();
    }, 1100);
  }

  // Première ouverture sur ce téléphone : on demande le prénom avant d'entrer
  function askName() {
    const form = document.createElement("form");
    form.className = "namegate";
    form.innerHTML = `
      <p class="namegate__eyebrow">BAV — Pass</p>
      <h1 class="namegate__title">Comment tu t'appelles ?</h1>
      <label class="sr-only" for="namegate-input">Ton prénom</label>
      <input class="namegate__input" id="namegate-input" name="prenom" type="text" maxlength="24"
             autocomplete="given-name" autocapitalize="words" enterkeyhint="go" placeholder="Ton prénom" required>
      <button class="btn btn--accent btn--lg" type="submit">C'est parti</button>
      <p class="namegate__note">Gardé uniquement sur ce téléphone.</p>`;
    el.classList.add("is-asking");
    document.body.append(form);
    const input = form.querySelector("input");
    setTimeout(() => input.focus(), 50);
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!setName(input.value)) return;
      window.dispatchEvent(new Event("bav:name"));
      form.classList.add("is-leaving");
      setTimeout(() => form.remove(), 500);
      finish();
    });
  }

  el.addEventListener("click", () => {
    if (getName()) finish();
    else if (!el.classList.contains("is-asking")) askName();
  });
}
