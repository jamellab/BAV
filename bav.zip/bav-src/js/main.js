// Point d'entrée de BAV : monte le cadre, enregistre les écrans, lance le routeur.

import { loadJSON } from "./data.js";
import { applyTheme, applyPalette } from "./theme.js";
import { mountShell } from "./shell.js";
import { register, startRouter } from "./router.js";
import { introNeeded, mountIntro } from "./intro.js";
import { hasPlacement } from "./words.js";
import { refresh } from "./progress.js";

import home from "./screens/home.js";
import vocabulary from "./screens/vocabulary.js";
import games from "./screens/games.js";
import grammar from "./screens/grammar.js";
import conversation from "./screens/conversation.js";
import music from "./screens/music.js";
import design from "./screens/design.js";
import placement from "./screens/placement.js";
import flashcards from "./screens/flashcards.js";
import cloze from "./screens/cloze.js";
import ordering from "./screens/ordering.js";
import dictation from "./screens/dictation.js";
import crossword from "./screens/crossword.js";
import verbs from "./screens/verbs.js";
import tree from "./screens/tree.js";
import grammarLesson from "./screens/grammarLesson.js";
import grammarQuiz from "./screens/grammarQuiz.js";

const { home: homeTab, modules } = await loadJSON("modules.json");

applyPalette();
applyTheme();
refresh(); // remise à zéro de la semaine (lundi) et du jour si besoin
if (introNeeded()) mountIntro(); // à chaque ouverture : écran d'entrée (voir js/intro.js)
mountShell(document.getElementById("app"), [homeTab, ...modules]);

[home, vocabulary, games, grammar, conversation, music, design, placement, flashcards, cloze, ordering, dictation, crossword, verbs, tree, grammarLesson, grammarQuiz].forEach(register);

// Toute première ouverture : le test de niveau passe en premier (derrière l'écran d'entrée et la saisie du prénom)
if (!hasPlacement() && location.hash !== "#/placement") location.hash = "#/placement";
startRouter(document.getElementById("view"));
