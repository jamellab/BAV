// Cadre commun des jeux : un jeu = une grande carte (même style que les cartes de l'accueil), des manches, puis une carte résultat.
// Les points d'XP sont donnés ici, une seule fois, à la fin (voir progress.js : barème et répétitions).

import { esc } from "./data.js";
import { icon } from "./icons.js";
import { toast } from "./components.js";
import { completeMission, setLast } from "./progress.js";
import { bindVoice } from "./voice.js";
import { userCefr } from "./words.js";
import { slideNavigate, slideArrive } from "./slide.js";
import { recordGame } from "./skills.js";

const pad = (n) => String(n).padStart(2, "0");

export const query = () => new URLSearchParams(location.hash.split("?")[1] || "");
// Un jeu lancé depuis l'arbre des compétences (« ?from=arbre ») revient à l'arbre
const backFor = (back) => (query().get("from") === "arbre" ? "#/arbre" : back);

// Niveau d'un jeu : celui de l'adresse (?d=2), sinon selon ton niveau d'anglais (A1 = Facile, A2 = Moyen, B1 = Défi)
const LEVEL_LABELS = ["Facile", "Moyen", "Défi"];
export const defaultLevel = (cefr) => (cefr === "A1" ? 1 : cefr === "A2" ? 2 : 3);
const levelNow = () => {
  const q = Number(query().get("d"));
  return q ? Math.min(3, Math.max(1, q)) : defaultLevel(userCefr());
};

/** Carte de jeu (même habillage que .slide, mais posée à plat dans la page). */
export function cardHTML({ tone = "paper", left = "", right = "", pct = null, body = "", foot = "" }) {
  return `<article class="slide play-card slide--${tone}">
    <header class="play-head">
      <div class="slide__meta"><span>${left}</span><span>${right}</span></div>
      ${pct == null ? "" : `<div class="line" style="--p:${Math.round(pct)}"><i></i></div>`}
    </header>
    <div class="slide__body play-body">${body}</div>
    <div class="play-foot">${foot}</div>
  </article>`;
}

/**
 * Crée un écran de jeu pour le routeur.
 * run(ctx) reçoit : ctx.host (zone de jeu), ctx.d (difficulté 1-3, adresse « ?d=2 »), ctx.finish({correct,total}), ctx.title…
 */
export function gameScreen({ path, title, game, module = "jeux", back = "#/jeux", run }) {
  return {
    path,
    title,
    async render() {
      const backLink = game === "placement" ? "" : `<a class="play-back" href="${backFor(back)}" data-back>${icon("arrowLeft")}<span>Retour</span></a>`;
      const hasLevels = !["placement", "flashcards", "grammar", "grammar-lesson"].includes(game);
      const now = levelNow();
      const pills = hasLevels
        ? `<div class="play-levels" role="group" aria-label="Niveau">${LEVEL_LABELS.map((l, k) => `<button type="button" class="play-lv" data-lv="${k + 1}" aria-pressed="${k + 1 === now}">${l}</button>`).join("")}</div>`
        : "";
      return `<section class="play deck-host" aria-label="${esc(title)}"><div class="play-top">${pills}</div><div class="play__host" aria-live="polite"></div></section>${backLink}`;
    },
    mount(root) {
      const host = root.querySelector(".play__host");
      const cleanups = [bindVoice(host)];
      const page = root.querySelector(".play");
      slideArrive(page);
      const onBack = (e) => {
        const a = e.target.closest("[data-back]");
        if (!a) return;
        e.preventDefault();
        slideNavigate(page, a.getAttribute("href"), "out");
      };
      // Changer de niveau : on relance le même jeu avec ?d=1, 2 ou 3
      const onLevel = (e) => {
        const b = e.target.closest("[data-lv]");
        if (!b) return;
        const q = query();
        q.set("d", b.dataset.lv);
        location.replace(`#${path}?${q.toString()}`);
      };
      root.addEventListener("click", onBack);
      root.addEventListener("click", onLevel);
      cleanups.push(() => { root.removeEventListener("click", onBack); root.removeEventListener("click", onLevel); });
      let dead = false;
      const d = levelNow();
      const ctx = {
        host, d, game, title, back: backFor(back), module,
        cefr: userCefr(),
        get dead() { return dead; },
        onCleanup: (fn) => cleanups.push(fn),
        restart: () => start(),
        finish: ({ correct, total }) => finishGame(ctx, correct, total),
      };
      function start() {
        host.innerHTML = cardHTML({ tone: "paper", left: esc(title), body: `<p class="slide__txt">Chargement…</p>` });
        Promise.resolve(run(ctx)).catch((err) => {
          console.error(err);
          host.innerHTML = cardHTML({
            tone: "deep", left: "Oups", body: `<p class="slide__txt">Ce jeu n'a pas pu démarrer. Réessaie dans un instant.</p>`,
            foot: `<a class="btn btn--accent btn--block" href="${back}">Retour</a>`,
          });
        });
      }
      if (game !== "placement") setLast({ route: location.hash.replace(/^#/, ""), title, module }); // « Reprendre » (accueil)
      start();
      return () => { dead = true; cleanups.forEach((f) => { try { f(); } catch { /* rien */ } }); };
    },
  };
}

function finishGame(ctx, correct, total) {
  const acc = total ? correct / total : 1;
  const r = completeMission(ctx.missionId || `${ctx.game}:${ctx.d}`, acc);
  if (ctx.afterFinish) ctx.afterFinish(acc); // ex. quiz de grammaire : enregistre le score de la leçon
  else if (!["placement", "flashcards"].includes(ctx.game)) recordGame(ctx.game, ctx.d, acc); // arbre des compétences
  const lines = r.repeat
    ? `<li><span>Mission déjà faite aujourd'hui</span><b>+${r.parts.base}</b></li>`
    : `<li><span>Mission terminée</span><b>+${r.parts.base}</b></li>` +
      (r.parts.precision ? `<li><span>Précision</span><b>+${r.parts.precision}</b></li>` : "") +
      (r.parts.streak ? `<li><span>Série de jours</span><b>+${r.parts.streak}</b></li>` : "");
  ctx.host.innerHTML = cardHTML({
    tone: "ink",
    left: "Terminé",
    right: `+${r.xp} XP`,
    pct: 100,
    body: `<p class="slide__num">${correct}<span style="font-size:.4em;letter-spacing:-.02em;opacity:.6">/${total}</span></p>
      <p class="slide__txt">${acc >= 0.8 ? "Très bien joué." : acc >= 0.5 ? "Bon début, ça rentre." : "Pas grave, on recommence, ça rentre."}</p>
      <ul class="xp-lines">${lines}</ul>`,
    foot: `<div class="play-actions"><button class="btn btn--accent" type="button" data-again>Rejouer</button><a class="btn btn--ghost" href="${ctx.back}">Retour</a></div>`,
  });
  ctx.host.querySelector("[data-again]").addEventListener("click", () => ctx.restart());
  if (r.tierUp) toast(`Palier ${r.tier} atteint cette semaine !`);
}

/**
 * Moteur de manches : pour chaque élément, build(item, i, n) renvoie { body, foot?, setup(api)? }.
 * Dans setup, api.answer(ok, htmlExplication) valide la manche ; un bouton « Continuer » apparaît.
 */
export function runRounds(ctx, items, build, { tone = "paper", right = null } = {}) {
  let i = 0;
  let correct = 0;
  let offs = [];
  const host = ctx.host;

  const onClick = (e) => {
    if (e.target.closest("[data-next]")) { i++; next(); }
  };
  host.addEventListener("click", onClick);
  ctx.onCleanup(() => { host.removeEventListener("click", onClick); offs.forEach((f) => f()); });

  function next() {
    offs.forEach((f) => f());
    offs = [];
    if (ctx.dead) return;
    if (i >= items.length) {
      host.removeEventListener("click", onClick); // sinon « Rejouer » empilerait les écouteurs
      return ctx.finish({ correct, total: items.length });
    }
    const q = build(items[i], i, items.length);
    host.innerHTML = cardHTML({
      tone,
      left: `${esc(ctx.title)} ${pad(i + 1)}/${pad(items.length)}`,
      right: right ? right(i, items.length) : `Niveau ${ctx.d}`,
      pct: (i / items.length) * 100,
      body: q.body,
      foot: q.foot || "",
    });
    const body = host.querySelector(".play-body");
    const foot = host.querySelector(".play-foot");
    let answered = false;
    const api = {
      body, foot, host,
      get answered() { return answered; },
      cleanup: (fn) => offs.push(fn),
      answer(ok, html = "") {
        if (answered) return;
        answered = true;
        if (ok) correct++;
        foot.innerHTML = `<div class="fb ${ok ? "fb--ok" : "fb--ko"}" role="status"><strong>${ok ? "Bien joué" : "Pas tout à fait"}</strong>${html ? `<span>${html}</span>` : ""}</div>
          <button class="btn btn--accent btn--block" data-next type="button">${i + 1 === items.length ? "Voir le résultat" : "Continuer"}</button>`;
        foot.querySelector("[data-next]").focus({ preventScroll: true });
      },
    };
    q.setup?.(api);
  }
  next();
}

/** Boutons de choix (QCM). Renvoie le code HTML ; l'index de chaque choix est dans data-i. */
export function optionsHTML(options, { lang = "en" } = {}) {
  return `<div class="opts" role="group">${options
    .map((o, k) => `<button type="button" class="opt" data-i="${k}" lang="${lang}">${esc(o)}</button>`)
    .join("")}</div>`;
}

/** Branche un QCM : au toucher, colore juste/faux puis appelle api.answer. */
export function bindOptions(api, correctIndex, explain = "") {
  const opts = [...api.body.querySelectorAll(".opt")];
  const onClick = (e) => {
    const b = e.target.closest(".opt");
    if (!b || api.answered) return;
    const k = Number(b.dataset.i);
    opts.forEach((o) => { o.disabled = true; });
    opts[correctIndex].classList.add("is-right");
    if (k !== correctIndex) b.classList.add("is-wrong");
    api.answer(k === correctIndex, explain);
  };
  api.body.addEventListener("click", onClick);
  api.cleanup(() => api.body.removeEventListener("click", onClick));
}

/**
 * Zone de saisie avec le clavier NATIF de l'appareil (iOS, Android…). Appelle onSubmit(texte) sur « OK » ou la touche Entrée.
 * Correcteur automatique, majuscules et suggestions sont coupés pour ne pas « corriger » la réponse.
 * Renvoie { set(text), get(), lock() }.
 */
export function mountTyping(api, slot, { onSubmit, max = 80, placeholder = "Écris ici", lang = "en" }) {
  slot.innerHTML = `<form class="typed-form" autocomplete="off">
    <input class="typed-input" type="text" lang="${lang}" inputmode="text" enterkeyhint="done" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" maxlength="${max}" placeholder="${esc(placeholder)}" aria-label="${esc(placeholder)}">
    <button class="btn btn--accent btn--sm typed-ok" type="submit">OK</button>
  </form>`;
  const form = slot.querySelector("form");
  const input = slot.querySelector("input");
  let locked = false;
  const onSubmitForm = (e) => {
    e.preventDefault();
    if (locked || !input.value.trim()) return;
    onSubmit(input.value);
  };
  form.addEventListener("submit", onSubmitForm);
  api.cleanup(() => form.removeEventListener("submit", onSubmitForm));
  try { input.focus({ preventScroll: true }); } catch { /* rien */ } // s'ouvre tout seul quand on vient de toucher « Continuer »
  return {
    get: () => input.value,
    set: (t) => { input.value = t; },
    lock: () => { locked = true; input.disabled = true; input.blur(); form.querySelector("button").disabled = true; },
  };
}

export const speakBtn = (text, label = "Écouter") =>
  `<button type="button" class="speak-btn" data-speak="${esc(text)}" aria-label="${label}">${icon("speaker")}<span>${label}</span></button>`;

export const slowBtn = () => `<button type="button" class="speak-btn speak-btn--slow" data-slow aria-pressed="false" aria-label="Mode lent">${icon("snail")}<span>Lent</span></button>`;
