// Profil de la personne : pour l'instant, juste le prénom, gardé sur CE téléphone (localStorage).
// Chaque téléphone a donc son propre prénom ; rien n'est envoyé nulle part.

const KEY = "bav:name";

export function getName() {
  try { return (localStorage.getItem(KEY) || "").trim(); } catch { return ""; }
}

export function setName(name) {
  const clean = String(name).trim().replace(/\s+/g, " ").slice(0, 24);
  try { localStorage.setItem(KEY, clean); } catch { /* mode privé : on ignore */ }
  return clean;
}
