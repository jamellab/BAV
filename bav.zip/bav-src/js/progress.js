// Progression : XP, paliers (remis à zéro chaque lundi, heure de Paris), série de jours, objectif du jour.
// Le NIVEAU D'ANGLAIS (A1/A2/B1) est séparé : il vient du test de placement, pas de l'XP.
// Rien ne se bloque : l'objectif du jour est un objectif, jamais une limite.

import { getData, update } from "./storage.js";

export const DAILY_GOAL = 4;        // missions par jour (~80 XP)
export const MISSION_XP = 20;       // XP d'une mission faite pour la 1re fois du jour
export const REPEAT_XP = 5;         // XP d'une mission déjà faite aujourd'hui (anti-triche, pas d'interdiction)

const TZ = "Europe/Paris";
const dayFmt = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" });
const wdFmt = new Intl.DateTimeFormat("en-US", { timeZone: TZ, weekday: "short" });

/** Date du jour à Paris, au format AAAA-MM-JJ. */
export function parisDate(date = new Date()) {
  return dayFmt.format(date);
}

export function addDays(dateStr, n) {
  const d = new Date(`${dateStr}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** Le lundi de la semaine en cours (Paris) : sert de clé pour la remise à zéro hebdomadaire. */
export function weekKey(date = new Date()) {
  const wd = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(wdFmt.format(date));
  return addDays(parisDate(date), -Math.max(0, wd));
}

/** Coût du palier n (pour passer de n à n+1) : 40 + 10 n XP. */
export const tierCost = (n) => 40 + 10 * n;

export function tierInfo(xp) {
  let n = 1;
  let rem = xp;
  while (rem >= tierCost(n)) { rem -= tierCost(n); n++; }
  const need = tierCost(n);
  return { tier: n, into: rem, need, pct: Math.round((rem / need) * 100) };
}

/** Remise à zéro de la semaine / du jour si on a changé de semaine / de jour. À appeler avant de lire. */
export function refresh() {
  const d = getData();
  const wk = weekKey();
  const today = parisDate();
  if (d.xp.weekKey !== wk || d.daily.date !== today) {
    update((x) => {
      if (x.xp.weekKey !== wk) {
        x.xp.best = Math.max(x.xp.best, x.xp.week); // on garde le record
        x.xp.week = 0;
        x.xp.weekKey = wk;
      }
      if (x.daily.date !== today) x.daily = { date: today, missions: 0, xp: 0, runs: {} };
    });
  }
  return getData();
}

export function snapshot() {
  const d = refresh();
  const today = parisDate();
  const yesterday = addDays(today, -1);
  const alive = d.streak.last === today || d.streak.last === yesterday;
  const set = new Set(d.days);
  const last7 = [];
  for (let i = 6; i >= 0; i--) {
    const day = addDays(today, -i);
    last7.push({ day, state: set.has(day) ? "done" : i === 0 ? "today" : "missed" });
  }
  return {
    week: d.xp.week,
    weekBest: Math.max(d.xp.best, d.xp.week),
    total: d.xp.total,
    tier: tierInfo(d.xp.week),
    streak: alive ? d.streak.current : 0,
    streakBest: Math.max(d.streak.best, alive ? d.streak.current : 0),
    last7,
    missionsToday: d.daily.missions,
    xpToday: d.daily.xp,
    goal: DAILY_GOAL,
    activeToday: set.has(today),
  };
}

/**
 * Enregistre une mission terminée.
 * @param {string} id        identifiant de la mission (ex. "crossword:1") : sert à repérer les répétitions du jour
 * @param {number} accuracy  de 0 à 1 (réponses justes)
 * @returns {{xp:number, repeat:boolean, parts:{base:number, precision:number, streak:number}, tierUp:boolean, tier:number}}
 */
export function completeMission(id, accuracy = 1) {
  refresh();
  const today = parisDate();
  const before = tierInfo(getData().xp.week).tier;
  let result;
  update((d) => {
    const runs = d.daily.runs[id] || 0;
    const repeat = runs > 0;
    const firstOfDay = d.daily.missions === 0;
    let parts;
    if (repeat) {
      parts = { base: REPEAT_XP, precision: 0, streak: 0 };
    } else {
      const precision = Math.round(10 * Math.max(0, (accuracy - 0.6) / 0.4)); // bonus précision : jusqu'à +10
      parts = { base: MISSION_XP, precision, streak: 0 };
    }
    // série de jours : la 1re mission du jour compte
    if (firstOfDay || !d.days.includes(today)) {
      const yesterday = addDays(today, -1);
      d.streak.current = d.streak.last === yesterday ? d.streak.current + 1 : d.streak.last === today ? d.streak.current : 1;
      d.streak.last = today;
      d.streak.best = Math.max(d.streak.best, d.streak.current);
      if (!d.days.includes(today)) d.days.push(today);
      d.days = d.days.slice(-40);
      if (!repeat) parts.streak = Math.min(5, d.streak.current); // bonus de série (jusqu'à +5)
    }
    const xp = parts.base + parts.precision + parts.streak;
    d.daily.runs[id] = runs + 1;
    d.daily.missions += 1;
    d.daily.xp += xp;
    d.xp.total += xp;
    d.xp.week += xp;
    result = { xp, repeat, parts };
  });
  const after = tierInfo(getData().xp.week).tier;
  return { ...result, tier: after, tierUp: after > before };
}

export const setLast = (last) => update((d) => { d.last = last; });
