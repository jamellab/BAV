// Routeur : affiche le bon écran selon l'adresse (#/vocabulaire, #/grammaire…).
// Chaque écran est un objet { path, title, layout?, render(), mount?() } enregistré dans main.js.
// mount() peut renvoyer une fonction de nettoyage, appelée quand on quitte l'écran.
// On utilise le « # » dans l'adresse : ça marche sur Vercel sans configuration supplémentaire.

import { highlightTab } from "./shell.js";
import { esc } from "./data.js";
import { finishMorph } from "./slide.js";

const routes = new Map();
let outlet;
let cleanup = null; // fonction renvoyée par mount() de l'écran précédent
let token = 0; // évite d'afficher un vieil écran si on a navigué entre-temps

export function register(screen) {
  routes.set(screen.path, screen);
}

export function startRouter(el) {
  outlet = el;
  window.addEventListener("hashchange", show);
  show();
}

function currentPath() {
  return (location.hash.replace(/^#/, "") || "/").split("?")[0];
}

async function show() {
  const path = currentPath();
  const screen = routes.get(path);
  const me = ++token;

  let html;
  try {
    html = screen ? await screen.render() : notFound(path);
  } catch (err) {
    console.error(err);
    html = errorView();
  }
  if (me !== token) return;

  if (cleanup) { cleanup(); cleanup = null; }
  outlet.classList.remove("view--in");
  outlet.classList.toggle("main--stage", screen?.layout === "stage");
  outlet.innerHTML = html;
  void outlet.offsetWidth; // relance l'animation d'apparition
  outlet.classList.add("view--in");

  document.title = screen ? `${screen.title} · BAV` : "Page introuvable · BAV";
  highlightTab(screen ? path : null);
  window.scrollTo(0, 0);
  outlet.focus({ preventScroll: true });
  cleanup = screen?.mount?.(outlet) ?? null;
  // si une carte vient de s'agrandir pour ouvrir cet écran, on la fait se fondre
  requestAnimationFrame(() => requestAnimationFrame(finishMorph));
}

function notFound(path) {
  return `<section class="empty"><div class="empty__hero">
    <h1 class="empty__title">Oups, page introuvable</h1>
    <p class="empty__text">L'adresse « ${esc(path)} » n'existe pas.</p>
    <a class="btn" href="#/">Retour à l'accueil</a></div></section>`;
}

function errorView() {
  return `<section class="empty"><div class="empty__hero">
    <h1 class="empty__title">Un souci est survenu</h1>
    <p class="empty__text">Le contenu n'a pas pu se charger. Vérifie ta connexion puis réessaie.</p>
    <button class="btn" type="button" onclick="location.reload()">Réessayer</button></div></section>`;
}
