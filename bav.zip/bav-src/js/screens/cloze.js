// Jeu : phrases à trous.
// Niveau 1 : 3 choix + traduction française visible. Niveau 2 : 4 choix, traduction à la demande.
// Niveau 3 : on tape le mot (indice : première lettre et nombre de lettres).

import { esc } from "../data.js";
import { loadWords, poolFor, clozeParts, isPlainWord, sample, norm, isBeginner } from "../words.js";
import { gameScreen, runRounds, optionsHTML, bindOptions, mountTyping, speakBtn } from "../play.js";

const ROUNDS = 10;

export default gameScreen({
  path: "/jeux/phrases-a-trous",
  title: "Phrases à trous",
  game: "cloze",
  async run(ctx) {
    const words = await loadWords();
    const pool = poolFor(words, ctx.cefr).filter((w) => isPlainWord(w) && clozeParts(w) && w.ex.split(" ").length >= 4);
    const items = sample(pool, ROUNDS);

    runRounds(ctx, items, (w) => {
      const [before, token, after] = clozeParts(w);
      const gap = `<span class="gap" aria-label="mot manquant">${"_".repeat(Math.max(4, w.en.length))}</span>`;
      const sentence = `<p class="sentence" lang="en">${esc(before)}${gap}${esc(after)}</p>`;
      const showFr = ctx.d === 1 || (ctx.d === 2 && isBeginner());
      const fr = showFr
        ? `<p class="slide__small trad">${esc(w.exFr)}</p>`
        : `<button type="button" class="link-btn" data-trad>Voir la traduction</button><p class="slide__small trad" hidden>${esc(w.exFr)}</p>`;

      if (ctx.d <= 2) {
        const nOpts = ctx.d === 1 ? 3 : 4;
        const same = pool.filter((x) => x.pos === w.pos && x.en.toLowerCase() !== w.en.toLowerCase());
        const wrong = sample(same.length >= nOpts - 1 ? same : pool.filter((x) => x.en !== w.en), nOpts - 1).map((x) => x.en);
        const options = sample([w.en, ...wrong], nOpts);
        return {
          body: `${sentence}${fr}${optionsHTML(options)}`,
          setup(api) {
            bindOptions(api, options.indexOf(w.en), `${speakBtn(w.ex, "Réécouter")}<em lang="en">${esc(w.en)}</em> : ${esc(w.fr)}`);
            const t = api.body.querySelector("[data-trad]");
            t?.addEventListener("click", () => { t.hidden = true; api.body.querySelector(".trad").hidden = false; });
          },
        };
      }
      // Niveau 3 : saisie
      return {
        body: `${sentence}${fr}<p class="slide__small">Commence par « ${esc(w.en[0])} » · ${w.en.length} lettres</p><div class="typing-slot"></div>`,
        setup(api) {
          const t = api.body.querySelector("[data-trad]");
          t?.addEventListener("click", () => { t.hidden = true; api.body.querySelector(".trad").hidden = false; });
          const field = mountTyping(api, api.body.querySelector(".typing-slot"), {
            max: 20,
            onSubmit: (txt) => {
              field.lock();
              const ok = norm(txt) === norm(token);
              api.body.querySelector(".gap").textContent = token;
              api.answer(ok, `${speakBtn(w.ex, "Réécouter")}<em lang="en">${esc(w.en)}</em> : ${esc(w.fr)}`);
            },
          });
        },
      };
    });
  },
});
