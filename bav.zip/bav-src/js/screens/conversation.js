// Écran « Conversation » : cartes 3D en boucle (voir moduleDeck.js). Missions factices pour l'instant.

import { moduleScreen } from "./moduleDeck.js";

export default { path: "/conversation", title: "Conversation", layout: "stage", ...moduleScreen("conversation") };
