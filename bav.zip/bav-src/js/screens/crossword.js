// Jeu : mots croisés. La grille est fabriquée à chaque partie à partir des mots du niveau (jamais la même).
// Débutant : l'indice est la traduction française. Intermédiaire : une phrase anglaise avec un trou.
// Taille : niveau 1 = 6 mots, niveau 2 = 8 mots, niveau 3 = 10 mots.

import { esc } from "../data.js";
import { loadWords, poolFor, isPlainWord, clozeParts, sample, isBeginner } from "../words.js";
import { gameScreen, cardHTML } from "../play.js";

const TARGET = { 1: 6, 2: 8, 3: 10 };
const MAX_COLS = 11;
const MAX_ROWS = 13;

/** Place des mots en grille (algorithme glouton : on cherche les croisements). Renvoie la liste des mots placés. */
function build(cands, target) {
  const grid = new Map();   // "r,c" -> lettre
  const dirsAt = new Map(); // "r,c" -> [bool across, bool down]
  const placed = [];
  const key = (r, c) => `${r},${c}`;
  let minR = 0, maxR = 0, minC = 0, maxC = 0;

  function fits(word, r0, c0, dir) {
    const dr = dir ? 1 : 0, dc = dir ? 0 : 1;
    const len = word.length;
    const nr0 = Math.min(minR, r0), nr1 = Math.max(maxR, r0 + dr * (len - 1));
    const nc0 = Math.min(minC, c0), nc1 = Math.max(maxC, c0 + dc * (len - 1));
    if (nr1 - nr0 + 1 > MAX_ROWS || nc1 - nc0 + 1 > MAX_COLS) return -1;
    if (grid.has(key(r0 - dr, c0 - dc)) || grid.has(key(r0 + dr * len, c0 + dc * len))) return -1;
    let cross = 0;
    for (let i = 0; i < len; i++) {
      const r = r0 + dr * i, c = c0 + dc * i;
      const ex = grid.get(key(r, c));
      if (ex) {
        if (ex !== word[i]) return -1;
        if (dirsAt.get(key(r, c))[dir]) return -1; // déjà un mot dans le même sens ici
        cross++;
      } else if (grid.has(key(r + dc, c + dr)) || grid.has(key(r - dc, c - dr))) {
        return -1; // un voisin collé sur le côté : lettres collées interdites
      }
    }
    return cross;
  }
  function put(word, r0, c0, dir) {
    const dr = dir ? 1 : 0, dc = dir ? 0 : 1;
    for (let i = 0; i < word.answer.length; i++) {
      const k = key(r0 + dr * i, c0 + dc * i);
      grid.set(k, word.answer[i]);
      const d = dirsAt.get(k) || [false, false];
      d[dir] = true;
      dirsAt.set(k, d);
    }
    const endR = r0 + dr * (word.answer.length - 1), endC = c0 + dc * (word.answer.length - 1);
    minR = Math.min(minR, r0); maxR = Math.max(maxR, endR); minC = Math.min(minC, c0); maxC = Math.max(maxC, endC);
    placed.push({ ...word, r: r0, c: c0, dir });
  }

  put(cands[0], 0, 0, 0);
  for (const w of cands.slice(1)) {
    if (placed.length >= target) break;
    let best = [], bestCross = 0;
    for (const [k, letter] of grid) {
      const [r, c] = k.split(",").map(Number);
      for (let i = 0; i < w.answer.length; i++) {
        if (w.answer[i] !== letter) continue;
        for (const dir of [0, 1]) {
          const r0 = dir ? r - i : r, c0 = dir ? c : c - i;
          const x = fits(w.answer, r0, c0, dir);
          if (x > bestCross) { bestCross = x; best = [[r0, c0, dir]]; }
          else if (x === bestCross && x > 0) best.push([r0, c0, dir]);
        }
      }
    }
    if (best.length) { const [r0, c0, dir] = best[Math.floor(Math.random() * best.length)]; put(w, r0, c0, dir); }
  }
  // origine en (0,0)
  return placed.map((p) => ({ ...p, r: p.r - minR, c: p.c - minC }));
}

function generate(cands, target) {
  let best = [];
  for (let t = 0; t < 80 && best.length < target; t++) {
    const order = sample(cands, cands.length).sort((a, b) => b.answer.length - a.answer.length + (Math.random() - 0.5) * 4);
    const res = build(order, target);
    if (res.length > best.length) best = res;
  }
  return best;
}

export default gameScreen({
  path: "/jeux/mots-croises",
  title: "Mots croisés",
  game: "crossword",
  async run(ctx) {
    const words = await loadWords();
    const beginner = isBeginner();
    const target = TARGET[ctx.d];
    const pool = poolFor(words, ctx.cefr).filter((w) => isPlainWord(w) && w.en.length >= 3 && w.en.length <= 8 && (beginner || clozeParts(w)));
    const cands = sample(pool, target + 10).map((w) => ({
      answer: w.en.toLowerCase(),
      clue: beginner ? w.fr : (() => { const [b, , a] = clozeParts(w); return `${b}____${a}`; })(),
      fr: w.fr,
      en: w.en,
    }));
    const list = generate(cands, target);
    if (list.length < 3) throw new Error("grille impossible");

    // numérotation (ordre de lecture) et cases
    const starts = [...new Set(list.map((w) => `${w.r},${w.c}`))]
      .map((s) => s.split(",").map(Number))
      .sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const numAt = new Map(starts.map(([r, c], i) => [`${r},${c}`, i + 1]));
    list.forEach((w) => { w.n = numAt.get(`${w.r},${w.c}`); });
    const rows = Math.max(...list.map((w) => w.r + (w.dir ? w.answer.length : 1)));
    const cols = Math.max(...list.map((w) => w.c + (w.dir ? 1 : w.answer.length)));
    const cells = new Map(); // "r,c" -> { r, c, a: lettre juste, v: saisie, words: [idx mot across, idx mot down] }
    list.forEach((w, wi) => {
      for (let i = 0; i < w.answer.length; i++) {
        const r = w.r + (w.dir ? i : 0), c = w.c + (w.dir ? 0 : i);
        const k = `${r},${c}`;
        const cell = cells.get(k) || { r, c, a: w.answer[i], v: "", words: [-1, -1] };
        cell.words[w.dir] = wi;
        cells.set(k, cell);
      }
    });

    let sel = { r: list[0].r, c: list[0].c, dir: list[0].dir };
    let wrongChecks = 0, hints = 0, done = false;
    const wordOf = (cell, dir) => (cell.words[dir] >= 0 ? cell.words[dir] : cell.words[1 - dir]);

    function activeWord() {
      const cell = cells.get(`${sel.r},${sel.c}`);
      const wi = cell.words[sel.dir] >= 0 ? cell.words[sel.dir] : cell.words[1 - sel.dir];
      if (cell.words[sel.dir] < 0) sel.dir = 1 - sel.dir;
      return list[wi];
    }
    const cellsOf = (w) => Array.from({ length: w.answer.length }, (_, i) => cells.get(`${w.r + (w.dir ? i : 0)},${w.c + (w.dir ? 0 : i)}`));

    const clueItem = (w, wi) => `<li><button type="button" class="clue" data-w="${wi}"><b>${w.n}</b><span lang="${beginner ? "fr" : "en"}">${esc(w.clue)}</span><small>${w.answer.length}</small></button></li>`;
    const clues = (dir) => list.map((w, wi) => (w.dir === dir ? clueItem(w, wi) : "")).join("");

    ctx.host.innerHTML = cardHTML({
      tone: "paper",
      left: `Mots croisés · ${list.length} mots`,
      right: `Niveau ${ctx.d}`,
      pct: 0,
      body: `<p class="slide__small" data-now></p>
        <div class="cw-wrap">
        <div class="cw" style="--cols:${cols};--rows:${rows}" role="grid" aria-label="Grille de mots croisés">
          ${Array.from({ length: rows * cols }, (_, i) => {
            const r = Math.floor(i / cols), c = i % cols;
            const cell = cells.get(`${r},${c}`);
            if (!cell) return `<i class="cw__block" aria-hidden="true"></i>`;
            const n = numAt.get(`${r},${c}`);
            return `<button type="button" class="cw__cell" data-r="${r}" data-c="${c}" role="gridcell" aria-label="Case ${r + 1}-${c + 1}">${n ? `<sup>${n}</sup>` : ""}<span></span></button>`;
          }).join("")}
        </div>
        <input class="cw__input" type="text" inputmode="text" enterkeyhint="done" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" aria-label="Tape les lettres avec le clavier de ton appareil">
        </div>
        <div class="cw-clues">
          <section><h3>Horizontal</h3><ol>${clues(0)}</ol></section>
          <section><h3>Vertical</h3><ol>${clues(1)}</ol></section>
        </div>`,
      foot: `<div class="play-actions"><button type="button" class="btn btn--ghost btn--sm" data-hint>Indice (−)</button><button type="button" class="btn btn--accent btn--sm" data-check>Vérifier</button></div>`,
    });
    const host = ctx.host;
    const cellEls = new Map([...host.querySelectorAll(".cw__cell")].map((b) => [`${b.dataset.r},${b.dataset.c}`, b]));
    const now = host.querySelector("[data-now]");
    const lineFill = host.querySelector(".line");

    function paint() {
      const aw = activeWord();
      const inWord = new Set(cellsOf(aw).map((x) => `${x.r},${x.c}`));
      let filled = 0;
      for (const [k, el] of cellEls) {
        const cell = cells.get(k);
        el.querySelector("span").textContent = cell.v.toUpperCase();
        el.classList.toggle("is-word", inWord.has(k));
        el.classList.toggle("is-sel", k === `${sel.r},${sel.c}`);
        if (cell.v) filled++;
      }
      host.querySelectorAll(".clue").forEach((b) => b.classList.toggle("is-on", Number(b.dataset.w) === list.indexOf(aw)));
      now.innerHTML = `<b>${aw.n} ${aw.dir ? "vertical" : "horizontal"}</b> · <span lang="${beginner ? "fr" : "en"}">${esc(aw.clue)}</span> (${aw.answer.length})`;
      lineFill.style.setProperty("--p", Math.round((filled / cells.size) * 100));
    }
    const move = (step) => {
      const aw = activeWord();
      const cs = cellsOf(aw);
      const idx = cs.findIndex((x) => x.r === sel.r && x.c === sel.c);
      const nx = cs[Math.min(cs.length - 1, Math.max(0, idx + step))];
      sel.r = nx.r; sel.c = nx.c;
    };

    function finishIfDone() {
      if (![...cells.values()].every((x) => x.v === x.a)) return false;
      done = true;
      const acc = Math.max(0, 1 - 0.15 * wrongChecks - 0.08 * hints);
      setTimeout(() => !ctx.dead && ctx.finish({ correct: Math.round(acc * 10), total: 10 }), 700);
      host.querySelectorAll(".cw__cell").forEach((el) => el.classList.add("is-right"));
      return true;
    }

    // ----- Saisie : le clavier NATIF de l'appareil (iOS, Android…), via un champ invisible placé dans la grille -----
    const press = (k) => {
      if (done) return;
      const cell = cells.get(`${sel.r},${sel.c}`);
      if (k === "Backspace") {
        if (cell.v) cell.v = ""; else { move(-1); cells.get(`${sel.r},${sel.c}`).v = ""; }
      } else if (/^[a-z]$/.test(k)) {
        cell.v = k;
        move(1);
      } else return;
      paint();
      finishIfDone();
    };
    // Un caractère invisible reste dans le champ : sans lui, la touche « effacer » ne déclencherait rien quand le champ est vide.
    const SENT = "\u200b";
    const input = host.querySelector(".cw__input");
    const resetInput = () => { input.value = SENT; try { input.setSelectionRange(1, 1); } catch { /* rien */ } };
    resetInput();
    const onInput = (e) => {
      if (e.isComposing) return;
      const v = input.value;
      if (!v.includes(SENT) && !v) press("Backspace");
      else for (const ch of v.replace(/\u200b/g, "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()) press(ch);
      resetInput();
    };
    const onComposeEnd = () => onInput({ isComposing: false });
    const onInputKey = (e) => {
      if (e.key === "Enter") { e.preventDefault(); host.querySelector("[data-check]").click(); }
      else if (e.key === "Backspace" && input.value === SENT) { /* géré par « input » */ }
    };
    input.addEventListener("input", onInput);
    input.addEventListener("compositionend", onComposeEnd);
    input.addEventListener("keydown", onInputKey);
    const focusInput = () => { try { input.focus({ preventScroll: true }); } catch { input.focus(); } };

    // Clavier ouvert : on masque la liste d'indices et on réduit la grille pour la voir ENTIÈRE au-dessus du clavier.
    const vv = window.visualViewport;
    const card = host.querySelector(".play-card");
    const grid = host.querySelector(".cw");
    const page = host.closest(".play");
    const fit = () => {
      const open = !!vv && document.activeElement === input && vv.height < window.innerHeight - 120;
      card.classList.toggle("cw-kb", open);
      page?.classList.toggle("is-kb", open); // de la place sous la page pour pouvoir remonter la carte tout en haut
      if (!open) { grid.style.removeProperty("--cw-h"); return; }
      const bar = document.querySelector(".topbar")?.offsetHeight || 60;
      // on mesure la carte avec une grille de 200 px, puis on donne à la grille toute la hauteur qui reste au-dessus du clavier
      grid.style.setProperty("--cw-h", "200px");
      const extra = card.getBoundingClientRect().height - grid.getBoundingClientRect().height;
      const room = vv.height - bar - 16 - extra;
      grid.style.setProperty("--cw-h", `${Math.max(110, room)}px`);
      requestAnimationFrame(() => card.scrollIntoView({ block: "start", behavior: "smooth" }));
    };
    const onFocusChange = () => setTimeout(fit, 60);
    input.addEventListener("focus", onFocusChange);
    input.addEventListener("blur", onFocusChange);
    vv?.addEventListener("resize", fit);
    ctx.onCleanup(() => {
      input.removeEventListener("input", onInput);
      input.removeEventListener("compositionend", onComposeEnd);
      input.removeEventListener("keydown", onInputKey);
      input.removeEventListener("focus", onFocusChange);
      input.removeEventListener("blur", onFocusChange);
      vv?.removeEventListener("resize", fit);
    });

    const onClick = (e) => {
      if (done) return;
      const b = e.target.closest(".cw__cell");
      const cl = e.target.closest("[data-w]");
      if (b) {
        const r = Number(b.dataset.r), c = Number(b.dataset.c);
        const cell = cells.get(`${r},${c}`);
        if (sel.r === r && sel.c === c && cell.words[0] >= 0 && cell.words[1] >= 0) sel.dir = 1 - sel.dir; // 2e toucher : on change de sens
        else { sel.r = r; sel.c = c; if (cell.words[sel.dir] < 0) sel.dir = 1 - sel.dir; }
        paint();
        focusInput();
      } else if (cl) {
        const w = list[Number(cl.dataset.w)];
        sel = { r: w.r, c: w.c, dir: w.dir };
        paint();
        focusInput();
      } else if (e.target.closest("[data-hint]")) {
        const aw = activeWord();
        const empty = cellsOf(aw).find((x) => x.v !== x.a);
        if (empty) { empty.v = empty.a; hints++; paint(); finishIfDone(); }
      } else if (e.target.closest("[data-check]")) {
        let bad = 0;
        for (const [k, el] of cellEls) {
          const cell = cells.get(k);
          const wrong = cell.v && cell.v !== cell.a;
          if (wrong) { bad++; el.classList.add("is-wrong"); setTimeout(() => el.classList.remove("is-wrong"), 1400); }
        }
        if (bad) wrongChecks++;
        if (!bad && !finishIfDone()) { now.textContent = "Rien de faux pour l'instant, continue."; }
        else if (bad) { now.textContent = `${bad} case${bad > 1 ? "s" : ""} à corriger (en rouge un instant).`; }
      }
    };
    host.addEventListener("click", onClick);
    ctx.onCleanup(() => host.removeEventListener("click", onClick));
    paint();
    focusInput(); // ordinateur : on peut taper tout de suite (sur téléphone, le clavier s'ouvre au 1er toucher d'une case)
  },
});

export const _test = { generate }; // utilisé uniquement par les vérifications automatiques
