// Guide de style : montre tous les éléments du design système au même endroit
// (couleurs, typo, boutons, cartes, progression, thème). Sert de référence pour la suite.

import { icon } from "../icons.js";
import { bar, ring, toast } from "../components.js";
import { logoSVG } from "../brand.js";
import { getTheme, setTheme } from "../theme.js";

const COLORS = [
  ["Fond", "--bg"], ["Surface", "--surface"], ["Surface 2", "--surface-2"], ["Trait", "--line"],
  ["Texte", "--ink"], ["Texte doux", "--ink-soft"], ["Action", "--primary"], ["Accent", "--accent"],
  ["Vocabulaire", "--c-vocab"], ["Grammaire", "--c-grammar"], ["Conversation", "--c-conv"], ["Musique", "--c-music"],
];

const swatches = COLORS.map(
  ([name, v]) => `<div class="swatch"><span class="swatch__chip" style="background:var(${v})"></span><span><b>${name}</b><code>${v}</code></span></div>`
).join("");

export default {
  path: "/design",
  title: "Guide de style",

  render() {
    return `
    <div class="guide">
      <header>
        <p class="eyebrow">Design système</p>
        <h1>Guide de style</h1>
        <p class="guide__lead">Trois palettes (Glacier, Ocre, Lilas), choisies avec le bouton en haut à droite. Un seul fichier (<code>css/tokens.css</code>) pilote tout.</p>
      </header>

      <section><h2>Logo</h2>
        <div class="card row" style="justify-content:space-between">
          <span style="width:11rem">${logoSVG()}</span>
          <span style="width:3.2rem">${logoSVG({ word: false, label: "Icône BAV" })}</span>
        </div>
        <p class="guide__lead">Le mot BAV est dessiné avec la typo Styro. Elle n'est utilisée que pour le logo.</p>
      </section>

      <section><h2>Thème</h2>
        <div class="segmented" id="theme-seg" role="group" aria-label="Thème">
          <button type="button" data-theme-choice="auto">${icon("auto")} Auto</button>
          <button type="button" data-theme-choice="light">${icon("sun")} Clair</button>
          <button type="button" data-theme-choice="dark">${icon("moon")} Sombre</button>
        </div>
      </section>

      <section><h2>Couleurs</h2><div class="swatches">${swatches}</div></section>

      <section><h2>Typographie</h2>
        <div class="card">
          <div class="type-sample"><small>Titre 1 · Inter ExtraBold</small><h1>Speak English</h1></div>
          <div class="type-sample"><small>Titre 2</small><h2>Ton objectif du jour</h2></div>
          <div class="type-sample"><small>Titre 3</small><h3>Mini-leçon de grammaire</h3></div>
          <div class="type-sample"><small>Texte · Inter Regular</small><p>I would like a cup of coffee, please. <span style="color:var(--ink-soft)">Je voudrais un café, s'il vous plaît.</span></p></div>
          <div class="type-sample"><small>Petit texte</small><p style="font-size:var(--fs-sm);color:var(--ink-soft)">Lecture facile, même sur un petit écran.</p></div>
        </div>
      </section>

      <section><h2>Boutons</h2>
        <div class="row">
          <button class="btn" type="button">Principal ${icon("arrowRight")}</button>
          <button class="btn btn--accent" type="button">Accent</button>
          <button class="btn btn--secondary" type="button">Secondaire</button>
          <button class="btn btn--ghost" type="button">Contour</button>
        </div>
        <div class="row" style="margin-top:.75rem">
          <button class="btn btn--sm" type="button">Petit</button>
          <button class="btn btn--lg" type="button">Grand</button>
          <button class="btn" type="button" disabled>Désactivé</button>
          <button class="icon-btn" type="button" aria-label="Écouter" data-toast>${icon("speaker")}</button>
        </div>
      </section>

      <section><h2>Cartes</h2>
        <div class="demo-grid">
          <article class="card"><h3>Carte simple</h3><p style="color:var(--ink-soft);margin-top:.5rem">Fond blanc, bord fin, coins très arrondis.</p></article>
          <article class="card card--tint mod-conversation"><span class="icon-chip">${icon("chat")}</span><h3 style="margin-top:.75rem">Carte colorée</h3><p style="color:var(--ink-soft);margin-top:.5rem">La couleur dépend du module.</p></article>
          <a class="card" href="#/design" onclick="return false"><h3>Carte cliquable</h3><p style="color:var(--ink-soft);margin-top:.5rem">Elle se soulève au toucher.</p></a>
        </div>
      </section>

      <section><h2>Étiquettes et progression</h2>
        <div class="row"><span class="badge">Neutre</span><span class="badge badge--accent">${icon("target")} Niveau Débutant</span><span class="badge badge--mod mod-musique">Musique</span></div>
        <div class="card" style="margin-top:1rem;display:grid;gap:1rem">
          <div class="mod-vocabulaire">${bar(70, "Exemple vocabulaire")}</div>
          <div class="mod-grammaire">${bar(40, "Exemple grammaire")}</div>
          <div class="mod-conversation row" style="justify-content:center">${ring({ done: 15, goal: 20, unit: "mots" })}</div>
        </div>
      </section>
    </div>`;
  },

  mount(root) {
    const seg = root.querySelector("#theme-seg");
    const sync = () => seg.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.themeChoice === getTheme())));
    seg.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (b) setTheme(b.dataset.themeChoice);
    });
    window.addEventListener("themechange", sync);
    sync();
    root.querySelector("[data-toast]")?.addEventListener("click", () => toast("Exemple de message."));
  },
};
