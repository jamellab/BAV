// Jeu : dictée audio. On écoute (voix anglaise) puis on écrit ce qu'on entend.
// Niveau 1 : des mots. Niveau 2 : phrases courtes. Niveau 3 : phrases plus longues.
// Le mode lent et « Réécouter » sont toujours là.

import { esc } from "../data.js";
import { loadWords, poolFor, isPlainWord, sample, norm } from "../words.js";
import { gameScreen, runRounds, mountTyping, speakBtn, slowBtn } from "../play.js";
import { speak, voiceSupported, hasEnglishVoice, isSlow } from "../voice.js";

const ROUNDS = 8;
const RANGE = { 2: [3, 6], 3: [6, 12] };

export default gameScreen({
  path: "/jeux/dictee",
  title: "Dictée audio",
  game: "dictation",
  async run(ctx) {
    if (!voiceSupported()) {
      ctx.host.querySelector(".play-body").innerHTML = `<p class="slide__txt">Ton navigateur ne sait pas lire à voix haute. Essaie avec Chrome ou Safari.</p>`;
      return;
    }
    const words = await loadWords();
    const base = poolFor(words, ctx.cefr);
    let texts;
    if (ctx.d === 1) {
      texts = sample(base.filter(isPlainWord), ROUNDS).map((w) => ({ say: w.en, fr: w.fr }));
    } else {
      const [lo, hi] = RANGE[ctx.d];
      let pool = base.filter((w) => { const n = w.ex.split(" ").length; return n >= lo && n <= hi; });
      if (pool.length < ROUNDS) pool = base;
      texts = sample(pool, ROUNDS).map((w) => ({ say: w.ex, fr: w.exFr }));
    }

    // Écran de départ : sur iPhone, la voix ne démarre qu'après un toucher
    ctx.host.querySelector(".play-body").innerHTML = `<p class="slide__txt">Tu vas entendre ${texts.length} ${ctx.d === 1 ? "mots" : "phrases"} en anglais. Écoute, puis écris-les.</p>
      <p class="slide__small">${hasEnglishVoice() ? "Voix prête" : "Aucune voix anglaise détectée : voir le message qui s'affiche"}</p>`;
    ctx.host.querySelector(".play-foot").innerHTML = `<button class="btn btn--accent btn--block" type="button" data-go>Commencer</button>`;
    ctx.host.querySelector("[data-go]").addEventListener("click", () => {
      speak(texts[0].say);
      let first = true;
      runRounds(ctx, texts, (t) => {
        const long = ctx.d >= 2;
        return {
          body: `<div class="listen">
              <button type="button" class="listen__play" data-speak="${esc(t.say)}" aria-label="Écouter">▶</button>
              <div class="listen__side">${speakBtn(t.say, "Réécouter")}${slowBtn()}</div>
            </div>
            <div class="typing-slot"></div>`,
          setup(api) {
            api.body.querySelectorAll("[data-slow]").forEach((b) => b.setAttribute("aria-pressed", String(isSlow())));
            if (!first) speak(t.say); // les manches suivantes démarrent après le toucher « Continuer »
            first = false;
            const field = mountTyping(api, api.body.querySelector(".typing-slot"), {
              max: long ? 90 : 24,
              placeholder: "Écris ce que tu entends",
              onSubmit: (txt) => {
                field.lock();
                const ok = norm(txt) === norm(t.say);
                api.answer(ok, `<em lang="en">${esc(t.say)}</em> : ${esc(t.fr)}`);
              },
            });
          },
        };
      }, { tone: "mid" });
    }, { once: true });
  },
});
