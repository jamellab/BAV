// Vocabulaire : flashcards avec répétition espacée (boîtes de Leitner, voir srs.js).
// Débutant : la traduction française est visible. Intermédiaire : anglais d'abord, traduction à la demande.
// Adresse « ?mode=due » : uniquement les mots à revoir. Sinon : mots à revoir d'abord, puis mots nouveaux.

import { esc } from "../data.js";
import { loadWords, poolFor, isBeginner } from "../words.js";
import { pickSession, rate, cardState, counts } from "../srs.js";
import { gameScreen, runRounds, speakBtn, slowBtn, cardHTML, query } from "../play.js";
import { isSlow } from "../voice.js";

const POS = { n: "nom", v: "verbe", adj: "adjectif", adv: "adverbe", prep: "préposition", pron: "pronom", conj: "conjonction", det: "déterminant", phr: "expression" };
const GAP_TXT = ["aujourd'hui", "aujourd'hui", "demain", "dans 3 jours", "dans 1 semaine", "dans 2 semaines"];

export default gameScreen({
  path: "/vocabulaire/apprendre",
  title: "Flashcards",
  game: "flashcards",
  module: "vocabulaire",
  back: "#/vocabulaire",
  async run(ctx) {
    const words = await loadWords();
    const only = query().get("lv"); // « ?lv=A2 » : seulement les mots de ce niveau (nœuds de l'arbre des compétences)
    const pool = only ? words.filter((w) => w.cefr === only) : poolFor(words, ctx.cefr);
    const mode = query().get("mode");
    const due = mode === "due";
    const items = pickSession(mode === "new" ? pool.filter((w) => !cardState(w.id)) : pool, 10, { onlyDue: due });
    if (!items.length) {
      const c = counts(pool);
      ctx.host.innerHTML = cardHTML({
        tone: "deep",
        left: "Flashcards",
        right: "Rien à revoir",
        body: `<p class="slide__big slide__big--mod">Tout est à jour</p><p class="slide__txt">Aucun mot à revoir maintenant. ${c.learned} mots déjà vus, ${c.mastered} bien installés.</p>`,
        foot: `<a class="btn btn--accent btn--block" href="#/vocabulaire/apprendre">Apprendre de nouveaux mots</a>`,
      });
      return;
    }
    const beginner = isBeginner();

    runRounds(ctx, items, (w) => {
      const st = cardState(w.id);
      const rateBtns = `<div class="play-actions"><button class="btn btn--ghost" type="button" data-rate="0">À revoir</button><button class="btn btn--accent" type="button" data-rate="1">Je savais</button></div>`;
      const reveal = `<button class="btn btn--accent btn--block" type="button" data-reveal>Voir la traduction</button>`;
      return {
        body: `<p class="slide__small">${st ? `Boîte ${st.b} sur 5` : "Nouveau mot"} · ${esc(POS[w.pos] || w.pos)}</p>
          <p class="slide__big slide__big--mod" lang="en">${esc(w.en)}</p>
          <div class="speak-row">${speakBtn(w.en, "Écouter")}${slowBtn()}</div>
          <p class="sentence" lang="en">${esc(w.ex)}</p>
          <div class="trad-box" ${beginner ? "" : "hidden"}><p class="trad-word">${esc(w.fr)}</p><p class="slide__small trad">${esc(w.exFr)}</p></div>`,
        foot: beginner ? rateBtns : reveal,
        setup(api) {
          api.body.querySelectorAll("[data-slow]").forEach((b) => b.setAttribute("aria-pressed", String(isSlow())));
          const onFoot = (e) => {
            if (api.answered) return;
            if (e.target.closest("[data-reveal]")) {
              api.body.querySelector(".trad-box").hidden = false;
              api.foot.innerHTML = rateBtns;
              return;
            }
            const r = e.target.closest("[data-rate]");
            if (!r) return;
            const ok = r.dataset.rate === "1";
            rate(w.id, ok);
            const s = cardState(w.id);
            api.body.querySelector(".trad-box").hidden = false;
            api.answer(ok, `${ok ? "Il revient" : "On le revoit"} ${GAP_TXT[s.b]}.`);
          };
          api.foot.addEventListener("click", onFoot);
          api.cleanup(() => api.foot.removeEventListener("click", onFoot));
        },
      };
    }, { tone: "mid", right: (i, n) => `${n - i} à voir` });
  },
});
