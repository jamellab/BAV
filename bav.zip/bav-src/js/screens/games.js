// Module « Jeux » : cartes 3D en boucle (voir moduleDeck.js). Chaque carte ouvre ses 3 niveaux de difficulté, puis le jeu.

import { moduleScreen } from "./moduleDeck.js";

export default { path: "/jeux", title: "Jeux", layout: "stage", ...moduleScreen("jeux") };
