// Écran « Grammaire » : cartes 3D en boucle (voir moduleDeck.js), une carte par mini-leçon (contenu : data/grammar.json).
// Une carte ouvre la leçon si elle n'est pas lue ; le quiz si la leçon est lue mais pas encore maîtrisée ; la leçon (révision) sinon.

import { moduleScreen } from "./moduleDeck.js";
import { loadJSON } from "../data.js";
import { getData } from "../storage.js";
import { CLEAR_AT } from "../skills.js";

async function items() {
  const { lessons } = await loadJSON("grammar.json");
  const saved = getData().skills.lessons;
  return lessons.map((l) => {
    const s = saved[l.id] || {};
    const mastered = s.best >= CLEAR_AT;
    const route = s.done && !mastered ? `/grammaire/quiz?id=${l.id}` : `/grammaire/lecon?id=${l.id}`;
    return {
      title: l.title,
      glyph: "lesson",
      text: `${l.level} · ${l.teaser}`,
      cta: mastered ? "Revoir" : s.done ? "Faire le quiz" : "Lire la leçon",
      choices: [{ label: "Commencer", route }],
    };
  });
}

export default { path: "/grammaire", title: "Grammaire", layout: "stage", ...moduleScreen("grammaire", { items }) };
