// Mini-leçon de grammaire (#/grammaire/lecon?id=g1) : 3 pages courtes, en français, avec des exemples en anglais (voix).
// Débutant (A1) : les traductions des exemples sont visibles. Intermédiaire : l'anglais d'abord, traduction à la demande.
// Lire la dernière page marque la leçon comme « lue » dans l'arbre des compétences ; le quiz donne l'XP.

import { esc, loadJSON } from "../data.js";
import { icon } from "../icons.js";
import { gameScreen, cardHTML, query } from "../play.js";
import { isBeginner } from "../words.js";
import { recordLesson } from "../skills.js";

/** Texte simple : **gras** seulement (le reste est protégé). */
export const fmt = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

export default gameScreen({
  path: "/grammaire/lecon",
  title: "Grammaire",
  game: "grammar-lesson",
  module: "grammaire",
  back: "#/grammaire",
  async run(ctx) {
    const { lessons } = await loadJSON("grammar.json");
    const lesson = lessons.find((l) => l.id === query().get("id")) || lessons[0];
    const n = lesson.pages.length;
    const beginner = isBeginner();
    let i = 0;
    let shown = beginner;

    function show() {
      const p = lesson.pages[i];
      const last = i === n - 1;
      if (last) recordLesson(lesson.id); // leçon lue
      const ex = p.examples
        .map(([en, fr]) => `<li><span class="gx__en" lang="en">${esc(en)}</span><span class="gx__fr">${esc(fr)}</span><button type="button" class="speak-btn speak-btn--icon" data-speak="${esc(en.split(" → ").pop())}" aria-label="Écouter">${icon("speaker")}</button></li>`)
        .join("");
      ctx.host.innerHTML = cardHTML({
        tone: "paper",
        left: `${esc(lesson.title)} · ${i + 1}/${n}`,
        right: lesson.level,
        pct: ((i + 1) / n) * 100,
        body: `<h2 class="slide__big slide__big--mod">${esc(p.title)}</h2>
          <p class="slide__txt gx__text">${fmt(p.text)}</p>
          <ul class="gx" data-fr="${shown ? "shown" : "hidden"}">${ex}</ul>
          ${shown ? "" : `<button type="button" class="link-btn" data-trad>Voir les traductions</button>`}
          ${p.tip ? `<p class="gx__tip">${fmt(p.tip)}</p>` : ""}`,
        foot: `<div class="play-actions">${i ? `<button class="btn btn--ghost" type="button" data-prev>Précédent</button>` : ""}<button class="btn btn--accent" type="button" data-next>${last ? "Faire le quiz" : "Suivant"}</button></div>`,
      });
    }

    const onClick = (e) => {
      if (e.target.closest("[data-prev]")) { i = Math.max(0, i - 1); show(); window.scrollTo({ top: 0 }); }
      else if (e.target.closest("[data-next]")) {
        if (i < n - 1) { i++; show(); window.scrollTo({ top: 0 }); }
        else location.hash = `#/grammaire/quiz?id=${lesson.id}${query().get("from") ? `&from=${query().get("from")}` : ""}`;
      } else if (e.target.closest("[data-trad]")) {
        shown = true;
        ctx.host.querySelector(".gx")?.setAttribute("data-fr", "shown");
        e.target.closest("[data-trad]").remove();
      }
    };
    ctx.host.addEventListener("click", onClick);
    ctx.onCleanup(() => ctx.host.removeEventListener("click", onClick));
    show();
  },
});
