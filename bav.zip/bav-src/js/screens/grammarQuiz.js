// Quiz de grammaire corrigé (#/grammaire/quiz?id=g1) : 6 questions, chaque réponse est expliquée en français.
// L'XP est donnée à la fin (une fois par leçon et par jour au tarif plein) ; le meilleur score alimente l'arbre des compétences.

import { esc, loadJSON } from "../data.js";
import { gameScreen, runRounds, optionsHTML, bindOptions, speakBtn, query } from "../play.js";
import { shuffle } from "../srs.js";
import { recordLesson } from "../skills.js";
import { fmt } from "./grammarLesson.js";

export default gameScreen({
  path: "/grammaire/quiz",
  title: "Quiz de grammaire",
  game: "grammar",
  module: "grammaire",
  back: "#/grammaire",
  async run(ctx) {
    const { lessons } = await loadJSON("grammar.json");
    const lesson = lessons.find((l) => l.id === query().get("id")) || lessons[0];
    ctx.missionId = `grammar:${lesson.id}`;                       // une mission par leçon (pas de « répétition » d'une leçon à l'autre)
    ctx.afterFinish = (acc) => recordLesson(lesson.id, acc);      // meilleur score → arbre des compétences

    runRounds(
      ctx,
      shuffle(lesson.quiz),
      (item) => {
        const order = shuffle(item.choices.map((c, k) => ({ c, k })));
        const options = order.map((o) => o.c);
        const right = order.findIndex((o) => o.k === item.a);
        const gap = item.q.includes("___");
        const done = gap ? item.q.replace("___", item.choices[item.a]) : "";
        const prompt = gap
          ? `<p class="sentence" lang="en">${esc(item.q).replace("___", '<span class="gap">____</span>')}</p>`
          : `<p class="slide__txt">${esc(item.q)}</p>`;
        return {
          body: `<p class="slide__small">${esc(lesson.title)}</p>${prompt}${optionsHTML(options)}`,
          setup(api) {
            bindOptions(api, right, `${fmt(item.why)}${done ? ` ${speakBtn(done, "Écouter")}` : ""}`);
          },
        };
      },
      { right: () => lesson.level }
    );
  },
});
