// Écran d'accueil : une pile de 4 cartes qui tournent en 3D quand on fait défiler (toutes cliquables).
// La page reste fixe ; seul le défilement pilote les cartes (voir js/deck.js et css/deck.css).
// Session 2 : toutes les valeurs viennent de la VRAIE progression (storage.js / progress.js), plus de données factices.

import { loadJSON, esc } from "../data.js";
import { icon } from "../icons.js";
import { mountDeck } from "../deck.js";
import { getName } from "../profile.js";
import { getData } from "../storage.js";
import { snapshot, parisDate } from "../progress.js";
import { loadWords, poolFor, userCefr, wordOfTheDay, LEVEL_NAMES, hasPlacement } from "../words.js";
import { counts } from "../srs.js";
import { speak } from "../voice.js";
import { openCard, slideArrive } from "../slide.js";
import { toast } from "../components.js";
import { build } from "../skills.js";

const pad = (n) => String(n).padStart(2, "0");

export default {
  path: "/",
  title: "Accueil",
  layout: "stage",

  async render() {
    const [{ modules }, words] = await Promise.all([loadJSON("modules.json"), loadWords()]);
    const s = snapshot();
    const cefr = userCefr();
    const pool = poolFor(words, cefr);
    const c = counts(pool);
    const pct = Math.min(100, Math.round((s.missionsToday / s.goal) * 100));
    const total = 5;
    const meta = (i, label, right) => `<div class="slide__meta"><span>BAV ${pad(i)}/${pad(total)} — ${label}</span><span>${right}</span></div>`;
    const word = wordOfTheDay(words, parisDate());
    const last = getData().last;
    const level = hasPlacement() ? LEVEL_NAMES[cefr] : "Niveau à définir";

    // Chaque ligne de la carte « Modules » est cliquable : Vocabulaire ouvre directement les flashcards, Jeux ouvre ses cartes
    const rowFor = (m, i) => {
      let attrs;
      let side;
      if (m.id === "vocabulaire") { attrs = `data-go="#${m.items[0].choices[0].route}" data-target="game"`; side = `${c.learned} mots`; }
      else if (m.id === "jeux") { attrs = `data-go="#${m.path}" data-target="stage"`; side = `${m.items.length} jeux`; }
      else if (m.id === "grammaire") { attrs = `data-go="#${m.path}" data-target="stage"`; side = "8 leçons"; }
      else { attrs = `data-soon="${esc(m.label)}"`; side = "Bientôt"; }
      return `<li><a href="#${m.path}" ${attrs}><span class="n">${i + 1}</span><span class="name">${esc(m.label)}</span><span class="pct">${side}</span></a></li>`;
    };
    const rows = modules.map(rowFor).join("");
    const treePct = Math.round(build(await loadJSON("skills.json"), words).me.total * 100);

    const resumeTitle = last ? last.title : "Ton premier mot";
    const resumeHref = last ? `#${last.route}` : "#/vocabulaire/apprendre";

    return `
    <div class="deck-host"><div class="deck">
      <div class="deck-track">
        <div class="deck-stage">
          <div class="deck-cards">

            <article class="slide slide--accent" aria-label="Salut" data-go="${esc(resumeHref)}" data-target="game">
              ${meta(1, "Aujourd'hui", esc(level))}
              <div class="slide__body">
                <h1 class="slide__big" data-greet>Salut<br>${esc(getName() || "toi")}</h1>
                <div class="line" style="--p:${pct}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}" aria-label="Objectif du jour"><i></i></div>
                <p class="slide__txt">${s.missionsToday}/${s.goal} missions · ${s.streak} ${s.streak > 1 ? "jours" : "jour"} d'affilée</p>
              </div>
              <div class="slide__cta"><span>Continuer : ${esc(resumeTitle)}</span>${icon("arrowRight")}</div>
            </article>

            <article class="slide slide--ink" aria-label="Modules">
              ${meta(2, "Modules", `${modules.length} au total`)}
              <div class="slide__body"><ul class="rows rows--many">${rows}</ul></div>
              <div class="slide__hint"><span>Touche un module</span><span>↳</span></div>
            </article>

            <article class="slide slide--night" aria-label="Ton arbre de compétences" data-go="#/arbre" data-target="stage">
              ${meta(3, "Ton arbre", `${treePct} %`)}
              <div class="slide__body">
                <h2 class="slide__big" style="font-size:9.5cqi;line-height:.92">Ton<br>arbre</h2>
                <p class="slide__small">Ce que tu sais, ce qui vient ensuite</p>
              </div>
              <div class="slide__tree" aria-hidden="true">
                <svg viewBox="0 0 120 110"><path class="st-line" d="M60 108V84M60 84C44 74 28 66 14 50M60 84C54 66 40 46 36 22M60 84V8M60 84C66 66 80 46 84 22M60 84C76 74 92 66 106 50"/><circle class="st-dot st-on" cx="60" cy="84" r="5"/><circle class="st-dot st-on" cx="38" cy="70" r="3.6"/><circle class="st-dot st-on" cx="22" cy="58" r="3.6"/><circle class="st-dot st-dot--lit" cx="14" cy="50" r="4.4"/><circle class="st-dot st-on" cx="52" cy="62" r="3.6"/><circle class="st-dot" cx="43" cy="42" r="3.6"/><circle class="st-dot" cx="36" cy="22" r="4.4"/><circle class="st-dot st-on" cx="60" cy="60" r="3.6"/><circle class="st-dot st-dot--lit" cx="60" cy="36" r="3.6"/><circle class="st-dot" cx="60" cy="8" r="4.4"/><circle class="st-dot" cx="76" cy="46" r="3.6"/><circle class="st-dot" cx="84" cy="22" r="4.4"/><circle class="st-dot" cx="92" cy="66" r="3.6"/><circle class="st-dot" cx="106" cy="50" r="4.4"/></svg>
              </div>
              <div class="slide__cta"><span>Explorer</span>${icon("arrowRight")}</div>
            </article>

            <article class="slide slide--mid" aria-label="Palier de la semaine" data-go="#/jeux" data-target="stage">
              ${meta(4, "Palier", `${s.week} XP`)}
              <div class="slide__body">
                <h2 class="slide__big" style="font-size:9.5cqi;line-height:.92">Palier ${s.tier.tier}</h2>
                <div class="line" style="--p:${s.tier.pct}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${s.tier.pct}" aria-label="Avancement du palier"><i></i></div>
                <p class="slide__small">${s.tier.into}/${s.tier.need} XP · remise à zéro lundi</p>
              </div>
              <div class="slide__cta"><span>Gagner de l'XP</span>${icon("arrowRight")}</div>
            </article>

            <article class="slide slide--deep" aria-label="Mot du jour" data-speak-card>
              ${meta(5, "Mot du jour", "EN → FR")}
              <div class="slide__body">
                ${word
                  ? `<p class="slide__big" lang="en" style="color:var(--sl-accent)">${esc(word.en)}</p>
                <p class="slide__txt">${esc(word.fr)}</p>
                <p class="slide__small" lang="en" style="text-transform:none;letter-spacing:.02em">${esc(word.ex)}</p>`
                  : `<p class="slide__txt">Reviens demain.</p>`}
              </div>
              <div class="slide__cta" data-word="${word ? esc(word.en) : ""}" data-ex="${word ? esc(word.ex) : ""}"><span>Écouter</span>${icon("speaker")}</div>
            </article>

          </div>
          <nav class="deck-index" aria-label="Cartes"></nav>
        </div>
      </div>
    </div></div>`;
  },

  mount(root) {
    const host = root.querySelector(".deck-host");
    slideArrive(host);

    // le prénom vient d'être saisi (1re ouverture) : on met la carte à jour
    const onName = () => {
      const h = root.querySelector("[data-greet]");
      if (h) h.innerHTML = `Salut<br>${esc(getName())}`;
    };
    window.addEventListener("bav:name", onName);

    // Toute carte est cliquable : une ligne de module, une carte à destination, ou le mot du jour (1er toucher : le mot ; 2e : la phrase)
    let n = 0;
    // Toucher n'importe où sur une carte fait avancer. Sur la carte « Modules », un toucher entre deux lignes
    // ouvre la ligne la plus proche (en hauteur).
    const nearestRow = (card, y) => {
      let best = null, bd = Infinity;
      card.querySelectorAll("a[data-go], a[data-soon]").forEach((r) => {
        const b = r.getBoundingClientRect();
        const d = Math.abs((b.top + b.bottom) / 2 - y);
        if (d < bd) { bd = d; best = r; }
      });
      return best;
    };
    const onClick = (e) => {
      const card0 = e.target.closest(".slide");
      const row = e.target.closest("a[data-go], a[data-soon]") || (card0 && !card0.dataset.go ? nearestRow(card0, e.clientY) : null);
      if (row) {
        e.preventDefault();
        if (row.dataset.soon) toast(`${row.dataset.soon} arrive bientôt.`);
        else openCard(row.closest(".slide"), row.dataset.go, row.dataset.target);
        return;
      }
      const card = card0;
      if (!card) return;
      if (card.dataset.go) { openCard(card, card.dataset.go, card.dataset.target); return; }
      if (card.hasAttribute("data-speak-card")) {
        const cta = card.querySelector("[data-word]");
        const text = n % 2 === 0 ? cta.dataset.word : cta.dataset.ex;
        n++;
        if (text) speak(text);
      }
    };
    root.addEventListener("click", onClick);
    const stop = mountDeck(root.querySelector(".deck"));
    return () => { root.removeEventListener("click", onClick); window.removeEventListener("bav:name", onName); stop(); };
  },
};
