// Écran d'un module : même effet que l'accueil (cartes 3D en boucle), une carte par mission.
// Toucher une carte : elle s'ouvre (voir slide.js) et devient directement le jeu. Le niveau (Facile / Moyen / Défi) se règle
// dans le jeu, et démarre selon ton niveau d'anglais. Plus de menu intermédiaire.
// Données : data/modules.json. Un module sans « items » (grammaire, conversation, musique) affiche ses cartes « Bientôt ».

import { loadJSON, esc } from "../data.js";
import { icon, glyph } from "../icons.js";
import { toast } from "../components.js";
import { mountDeck } from "../deck.js";
import { slideNavigate, slideArrive, openCard } from "../slide.js";

const TONES = ["accent", "ink", "paper", "mid", "deep"];
const pad = (n) => String(n).padStart(2, "0");

export function moduleScreen(id, opts = {}) {
  let mod;
  return {
    async render() {
      const { modules } = await loadJSON("modules.json");
      mod = modules.find((m) => m.id === id);
      if (opts.items) mod = { ...mod, items: await opts.items() }; // cartes calculées (ex. leçons de grammaire)
      const live = Array.isArray(mod.items) && mod.items.length > 0;
      const list = live ? mod.items : mod.coming;
      const total = list.length;
      const meta = (i, right) =>
        `<div class="slide__meta"><span>${esc(mod.label)} ${pad(i)}/${pad(total)}</span><span>${right}</span></div>`;

      const cards = list
        .map((it, i) => {
          const tone = TONES[i % TONES.length];
          if (!live) {
            return `
        <article class="slide slide--${tone}" aria-label="${esc(it)}" data-soon>
          ${meta(i + 1, "Bientôt")}
          <div class="slide__body"><p class="slide__num">${i + 1}</p><p class="slide__txt">${esc(it)}</p></div>
          <div class="slide__cta"><span>Bientôt</span>${icon("arrowRight")}</div>
        </article>`;
          }
          const route = it.choices[0].route.replace(/\?d=\d+$/, ""); // le niveau (?d=) est choisi dans le jeu
          return `
        <article class="slide slide--${tone}" aria-label="${esc(it.title)}" data-go="#${esc(route)}" data-target="game">
          ${meta(i + 1, esc(it.cta || "Jouer"))}
          <div class="slide__body">
            <h2 class="slide__big slide__big--mod">${esc(it.title)}</h2>
            <p class="slide__txt">${esc(it.text)}</p>
          </div>
          <div class="slide__glyph" aria-hidden="true">${glyph(it.glyph)}</div>
          <div class="slide__cta"><span>${esc(it.cta || "Jouer")}</span>${icon("arrowRight")}</div>
        </article>`;
        })
        .join("");

      return `
      <div class="deck-host"><div class="deck"><div class="deck-track"><div class="deck-stage">
        <div class="deck-cards">${cards}</div>
        <nav class="deck-index" aria-label="Cartes"></nav>
      </div></div></div></div>
      <button class="deck-back deck-back--edge" type="button" aria-label="Retour à l'accueil"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 4 7 12l8 8"/></svg></button>`;
    },
    mount(root) {
      const host = root.querySelector(".deck-host");
      const back = root.querySelector(".deck-back");
      slideArrive(host);
      const stop = mountDeck(host.querySelector(".deck"));

      const onClick = (e) => {
        const card = e.target.closest(".slide");
        if (!card) return;
        if (card.dataset.go) openCard(card, card.dataset.go, card.dataset.target);
        else if (card.hasAttribute("data-soon")) toast(`${mod.label} arrive en session ${mod.session}.`);
      };
      const onBack = () => slideNavigate(host, "#/", "out");
      root.addEventListener("click", onClick);
      back.addEventListener("click", onBack);
      return () => { root.removeEventListener("click", onClick); back.removeEventListener("click", onBack); stop(); };
    },
  };
}
