// Écran « Musique » : cartes 3D en boucle (voir moduleDeck.js). Missions factices pour l'instant.

import { moduleScreen } from "./moduleDeck.js";

export default { path: "/musique", title: "Musique", layout: "stage", ...moduleScreen("musique") };
