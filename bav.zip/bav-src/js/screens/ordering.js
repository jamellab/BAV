// Jeu : phrase à remettre dans l'ordre. On touche les mots pour construire la phrase.
// Niveau 1 : phrases courtes, traduction visible. Niveau 2 : phrases moyennes. Niveau 3 : phrases longues, traduction cachée.

import { esc } from "../data.js";
import { loadWords, poolFor, sample, norm } from "../words.js";
import { gameScreen, runRounds, speakBtn } from "../play.js";

const ROUNDS = 8;
const RANGE = { 1: [4, 6], 2: [6, 9], 3: [8, 14] };

export default gameScreen({
  path: "/jeux/phrase-ordre",
  title: "Phrase dans l'ordre",
  game: "order",
  async run(ctx) {
    const words = await loadWords();
    const [lo, hi] = RANGE[ctx.d];
    let pool = poolFor(words, ctx.cefr).filter((w) => {
      const n = w.ex.split(" ").length;
      return n >= lo && n <= hi;
    });
    if (pool.length < ROUNDS) pool = poolFor(words, ctx.cefr).filter((w) => w.ex.split(" ").length >= 4);
    const seen = new Set();
    const items = sample(pool, ROUNDS * 2).filter((w) => !seen.has(w.ex) && seen.add(w.ex)).slice(0, ROUNDS);

    runRounds(ctx, items, (w) => {
      const tokens = w.ex.split(" ");
      let order = sample(tokens.map((t, i) => i), tokens.length);
      if (order.every((v, i) => v === i) && tokens.length > 1) order = order.reverse();
      const fr = ctx.d === 3 ? "" : `<p class="slide__small trad">${esc(w.exFr)}</p>`;
      return {
        body: `${fr}<div class="answer-line" data-answer aria-label="Ta phrase"></div><div class="tiles" data-tiles></div>`,
        foot: `<button class="btn btn--accent btn--block" type="button" data-check disabled>Vérifier</button>`,
        setup(api) {
          const ans = api.body.querySelector("[data-answer]");
          const bank = api.body.querySelector("[data-tiles]");
          const check = api.foot.querySelector("[data-check]");
          const placed = []; // indices de tokens dans l'ordre choisi
          const paint = () => {
            ans.innerHTML = placed.map((idx) => `<button type="button" class="tile tile--on" data-from="${idx}" lang="en">${esc(tokens[idx])}</button>`).join("");
            bank.innerHTML = order.filter((idx) => !placed.includes(idx))
              .map((idx) => `<button type="button" class="tile" data-to="${idx}" lang="en">${esc(tokens[idx])}</button>`).join("");
            check.disabled = placed.length !== tokens.length;
          };
          paint();
          const onClick = (e) => {
            if (api.answered) return;
            const to = e.target.closest("[data-to]");
            const from = e.target.closest("[data-from]");
            if (to) placed.push(Number(to.dataset.to));
            else if (from) placed.splice(placed.indexOf(Number(from.dataset.from)), 1);
            else return;
            paint();
          };
          api.body.addEventListener("click", onClick);
          api.cleanup(() => api.body.removeEventListener("click", onClick));
          check.addEventListener("click", () => {
            if (api.answered || placed.length !== tokens.length) return;
            const mine = placed.map((i) => tokens[i]).join(" ");
            const ok = norm(mine) === norm(w.ex);
            ans.classList.add(ok ? "is-right" : "is-wrong");
            api.answer(ok, `${speakBtn(w.ex, "Écouter")}<em lang="en">${esc(w.ex)}</em>`);
          });
        },
      };
    });
  },
});
