// Mini test de placement (12 questions, présentées en cartes). Il fixe le niveau d'anglais : A1 (débutant), A2 ou B1 (intermédiaire).
// Le niveau est jugé sur les RÉSULTATS, pas sur le nombre de missions. Pas d'XP ici. On peut le refaire quand on veut (menu Couleurs).

import { esc } from "../data.js";
import { update } from "../storage.js";
import { parisDate } from "../progress.js";
import { LEVEL_NAMES } from "../words.js";
import { gameScreen, runRounds, optionsHTML, cardHTML } from "../play.js";

// [consigne, question, choix, index de la bonne réponse, niveau]
const Q = [
  ["Que veut dire…", "apple", ["pomme", "pain", "eau", "fromage"], 0, "A1"],
  ["Complète", "I ___ a student.", ["am", "is", "are", "be"], 0, "A1"],
  ["Complète", "She ___ two brothers.", ["have", "has", "having", "haves"], 1, "A1"],
  ["Que veut dire…", "Thank you", ["bonjour", "merci", "au revoir", "s'il te plaît"], 1, "A1"],
  ["Complète", "Yesterday I ___ to the market.", ["go", "went", "gone", "going"], 1, "A2"],
  ["Complète", "This bag is ___ than that one.", ["heavy", "heavier", "more heavy", "heaviest"], 1, "A2"],
  ["Que veut dire…", "luggage", ["bagages", "bureau", "billet", "voyage"], 0, "A2"],
  ["Complète", "I ___ my homework when you called.", ["did", "do", "was doing", "am doing"], 2, "A2"],
  ["Complète", "If I ___ more time, I would learn Italian.", ["have", "had", "will have", "has"], 1, "B1"],
  ["Que veut dire…", "achievement", ["voisinage", "accord", "retard", "réussite"], 3, "B1"],
  ["Complète", "She suggested ___ early.", ["to leave", "leaving", "leave", "left"], 1, "B1"],
  ["Complète", "The report ___ by the manager yesterday.", ["wrote", "is writing", "was written", "has wrote"], 2, "B1"],
];

// Règle : A1 si les bases (A1) ne sont pas acquises ou si le niveau A2 reste fragile ; B1 si A2 et B1 sont bien réussis.
function levelFrom(s) {
  if (s.A1 < 3 || s.A2 < 2) return "A1";
  if (s.A2 >= 3 && s.B1 >= 2) return "B1";
  return "A2";
}

export default gameScreen({
  path: "/placement",
  title: "Test de niveau",
  game: "placement",
  back: "#/",
  async run(ctx) {
    const score = { A1: 0, A2: 0, B1: 0 };
    ctx.finish = ({ total }) => {
      const cefr = levelFrom(score);
      update((d) => { d.profile.cefr = cefr; d.profile.placedAt = parisDate(); });
      window.dispatchEvent(new Event("bav:level"));
      ctx.host.innerHTML = cardHTML({
        tone: "ink",
        left: "Test terminé",
        right: `${total} questions`,
        pct: 100,
        body: `<p class="slide__big slide__big--mod">${esc(LEVEL_NAMES[cefr])}</p>
          <p class="slide__txt">${cefr === "A1"
            ? "On part de la base : les traductions françaises seront visibles."
            : "Tu as déjà de bonnes bases : l'anglais d'abord, la traduction à la demande."}</p>
          <p class="slide__small">Tu pourras refaire le test quand tu veux (bouton Couleurs).</p>`,
        foot: `<a class="btn btn--accent btn--block" href="#/">C'est parti</a>`,
      });
    };

    ctx.host.innerHTML = cardHTML({
      tone: "accent",
      left: "BAV · Test de niveau",
      right: "12 questions",
      body: `<p class="slide__big slide__big--mod">On cherche ton niveau</p>
        <p class="slide__txt">12 petites questions, 2 minutes. Pas de note : si tu ne sais pas, touche « Je ne sais pas ».</p>`,
      foot: `<button class="btn btn--block" type="button" data-start>Commencer</button>`,
    });
    ctx.host.querySelector("[data-start]").addEventListener("click", () => {
      runRounds(ctx, Q, ([lead, q, choices, ok, lvl]) => ({
        body: `<p class="slide__small">${esc(lead)}</p><p class="sentence" lang="en">${esc(q)}</p>${optionsHTML(choices, { lang: lead === "Que veut dire…" ? "fr" : "en" })}
          <button type="button" class="link-btn" data-skip>Je ne sais pas</button>`,
        setup(api) {
          const opts = [...api.body.querySelectorAll(".opt")];
          const orig = api.answer;
          api.answer = (good, html) => { if (good) score[lvl]++; orig(good, html); };
          const onClick = (e) => {
            if (api.answered) return;
            const b = e.target.closest(".opt");
            const skip = e.target.closest("[data-skip]");
            if (!b && !skip) return;
            opts.forEach((o) => { o.disabled = true; });
            opts[ok].classList.add("is-right");
            if (b && Number(b.dataset.i) !== ok) b.classList.add("is-wrong");
            api.answer(!!b && Number(b.dataset.i) === ok, "");
          };
          api.body.addEventListener("click", onClick);
          api.cleanup(() => api.body.removeEventListener("click", onClick));
        },
      }), { tone: "accent", right: (i, n) => `${n - i} restantes` });
    }, { once: true });
  },
});
