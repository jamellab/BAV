// Écran « Arbre des compétences » (#/arbre) : ta progression sous forme d'arbre lumineux.
// - 5 branches = les 5 modules ; chaque nœud = un thème ; il s'éclaire quand tu progresses (états calculés dans js/skills.js).
// - On déplace la carte au doigt, on pince pour zoomer (js/camera.js). Rien ne se bloque : toucher un nœud ouvre son panneau.
// - Toucher un nœud : la caméra vole vers lui, il s'illumine, un panneau monte avec ses missions ; « Continuer » ouvre la mission
//   avec la même animation de carte qui grandit que le reste de l'appli.
// La géométrie est dans js/treeLayout.js, les données dans data/skills.json.

import { esc } from "../data.js";
import { icon, symbol } from "../icons.js";
import { loadSkills } from "../skills.js";
import { layout, WORLD } from "../treeLayout.js";
import { createCamera, easeOut } from "../camera.js";
import { slideNavigate, slideArrive, openCard } from "../slide.js";

const SEEN = "bav:tree-seen";
const reduced = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pctText = (x) => `${Math.round(x * 100)}`;
const STATE_TXT = { discover: "à découvrir", learning: "en cours", mastered: "maîtrisé", soon: "bientôt" };

const iconSvg = (name, size) => {
  const s = symbol(name);
  return `<svg class="node__icon" x="${-size / 2}" y="${-size / 2}" width="${size}" height="${size}" viewBox="0 0 ${s.vb} ${s.vb}" fill="none" stroke="currentColor" stroke-width="${s.sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${s.body}</svg>`;
};

function stars() {
  let seed = 7;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  return Array.from({ length: 54 }, () => {
    const x = (rnd() * 2400 - 500).toFixed(0), y = (rnd() * 2600 - 400).toFixed(0), r = (0.8 + rnd() * 1.8).toFixed(1);
    return `<circle cx="${x}" cy="${y}" r="${r}" style="animation-delay:${(rnd() * 5).toFixed(1)}s;animation-duration:${(3 + rnd() * 4).toFixed(1)}s"/>`;
  }).join("");
}

export default {
  path: "/arbre",
  title: "Arbre",
  layout: "stage",

  async render() {
    const sk = await loadSkills();
    const geo = layout(sk.def);
    this._sk = sk;
    this._geo = geo;

    const nodePos = {};
    geo.branches.forEach((b) => b.nodes.forEach((n) => { nodePos[n.id] = n; }));

    // ----- branches (chemins) -----
    let pulses = 0;
    const edges = geo.branches
      .map((b, bi) =>
        b.nodes
          .map((g) => {
            const n = sk.byId[g.id];
            const lit = n.state === "mastered" ? 1 : n.state === "learning" ? Math.min(1, 0.3 + n.progress * 0.7) : 0;
            const delay = (0.35 + bi * 0.09 + (g.spine ? 0 : 0.18)).toFixed(2);
            const pulse = lit && pulses++ < 9
              ? `<circle class="pulse" r="3.4"><animateMotion dur="${(3.2 + (pulses % 4) * 0.7).toFixed(1)}s" begin="${((pulses * 0.55) % 3).toFixed(1)}s" repeatCount="indefinite" path="${g.d}"/></circle>`
              : "";
            return `<g class="edge b-${b.id}" data-edge="${g.id}" style="--d:${delay}s">
              <path class="edge__base" d="${g.d}" pathLength="1"/>
              ${lit ? `<path class="edge__halo" d="${g.d}" pathLength="1" style="stroke-dasharray:${lit.toFixed(3)} 1;--lit:${lit.toFixed(3)}"/><path class="edge__lit" d="${g.d}" pathLength="1" style="stroke-dasharray:${lit.toFixed(3)} 1;--lit:${lit.toFixed(3)}"/>${pulse}` : ""}
            </g>`;
          })
          .join("")
      )
      .join("");

    // ----- nœuds -----
    const nodes = geo.branches
      .map((b, bi) =>
        b.nodes
          .map((g) => {
            const n = sk.byId[g.id];
            const rec = sk.recommended === n.id;
            const delay = (0.55 + bi * 0.09 + (g.spine ? 0.45 : 0.75)).toFixed(2);
            const r = g.r;
            const ring = n.live
              ? `<circle class="node__track" r="${r + 7}"/><circle class="node__ring" r="${r + 7}" pathLength="1" style="stroke-dasharray:${Math.max(n.progress, n.state === "learning" ? 0.06 : 0).toFixed(3)} 1;--lit:${Math.max(n.progress, n.state === "learning" ? 0.06 : 0).toFixed(3)}" transform="rotate(-90)"/>`
              : "";
            return `<g class="node n-${n.state} b-${b.id}${rec ? " is-rec" : ""}" data-node="${n.id}" transform="translate(${g.x.toFixed(1)} ${g.y.toFixed(1)})" style="--d:${delay}s" tabindex="0" role="button" aria-label="${esc(n.title)}, ${STATE_TXT[n.state]}">
              <g class="node__pop">
                <circle class="node__glow" r="${r * 2.6}" fill="url(#glow-${b.id})"/>
                ${rec ? `<circle class="node__ping" r="${r + 7}"/><circle class="node__ping node__ping--2" r="${r + 7}"/>` : ""}
                ${ring}
                <circle class="node__disc" r="${r}"/>
                ${iconSvg(n.icon, r * 0.86)}
                ${n.state === "mastered" ? `<g class="node__check" transform="translate(${r * 0.72} ${-r * 0.72})"><circle r="10"/><path d="M-4.5 0.5l3.2 3.2 6-6.4" fill="none" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></g>` : ""}
              </g>
              <circle class="node__hit" r="${r + 20}"/>
            </g>`;
          })
          .join("")
      )
      .join("");

    const h = geo.hub;
    const hubNode = `<g class="node node--hub n-learning" data-node="hub" transform="translate(${h.x} ${h.y})" style="--d:.5s" tabindex="0" role="button" aria-label="Toi, niveau ${sk.me.cefr}">
      <g class="node__pop">
        <circle class="node__glow" r="150" fill="url(#glow-hub)"/>
        <circle class="node__track" r="${52}"/><circle class="node__ring" r="52" pathLength="1" style="stroke-dasharray:${Math.max(0.04, sk.me.total).toFixed(3)} 1;--lit:${Math.max(0.04, sk.me.total).toFixed(3)}" transform="rotate(-90)"/>
        <circle class="node__disc" r="44"/>
        <text class="hub__lv" text-anchor="middle" y="9">${sk.me.cefr}</text>
      </g>
    </g>`;

    const root = geo.root;
    const ground = `
      <path class="trunk__base" d="${geo.trunk}" pathLength="1"/>
      <path class="trunk__lit" d="${geo.trunk}" pathLength="1"/>
      <path class="root" d="M${root.x} ${root.y}c-60 20 -130 30 -210 22" pathLength="1"/>
      <path class="root" d="M${root.x} ${root.y}c46 26 120 36 190 18" pathLength="1"/>
      <path class="root" d="M${root.x} ${root.y}c-14 34 -20 70 -50 100" pathLength="1"/>`;

    const glows = [...sk.branches.map((b) => b.id), "hub"]
      .map((id) => `<radialGradient id="glow-${id}"><stop offset="0" stop-color="var(--t-${id})" stop-opacity=".5"/><stop offset=".45" stop-color="var(--t-${id})" stop-opacity=".14"/><stop offset="1" stop-color="var(--t-${id})" stop-opacity="0"/></radialGradient>`)
      .join("");

    return `
    <section class="tree deck-host" aria-label="Arbre des compétences">
      <svg class="tree__svg" role="group" aria-label="Carte de tes compétences : déplace-la au doigt, touche un nœud pour l'ouvrir">
        <defs>${glows}<radialGradient id="aura"><stop offset="0" stop-color="var(--p-accent)" stop-opacity=".22"/><stop offset="1" stop-color="var(--p-accent)" stop-opacity="0"/></radialGradient></defs>
        <g class="tree__stars" aria-hidden="true">${stars()}</g>
        <g class="tree__world">
          <circle class="tree__aura" cx="${h.x}" cy="${h.y - 120}" r="760" fill="url(#aura)"/>
          <g class="ground">${ground}</g>
          <g class="edges">${edges}</g>
          <g class="nodes">${nodes}${hubNode}</g>
        </g>
      </svg>
      <button class="deck-back tree__back" type="button" aria-label="Retour à l'accueil">${icon("arrowRight")}<span>Retour</span></button>
      <button class="tree__rec" type="button">${icon("target")}<span>Pour toi</span></button>
      <aside class="tsheet" hidden aria-live="polite"></aside>
    </section>`;
  },

  mount(root) {
    const sk = this._sk;
    const geo = this._geo;
    const host = root.querySelector(".tree");
    const svg = host.querySelector(".tree__svg");
    const world = host.querySelector(".tree__world");
    const starsG = host.querySelector(".tree__stars");
    const sheet = host.querySelector(".tsheet");
    const recBtn = host.querySelector(".tree__rec");
    const back = host.querySelector(".tree__back");
    slideArrive(host);

    const seen = (() => { try { return sessionStorage.getItem(SEEN) === "1"; } catch { return false; } })();
    host.classList.toggle("tree--quick", seen || reduced());
    try { sessionStorage.setItem(SEEN, "1"); } catch { /* rien */ }

    const pos = { hub: { x: geo.hub.x, y: geo.hub.y, r: 44 } };
    geo.branches.forEach((b) => b.nodes.forEach((n) => { pos[n.id] = n; }));

    let current = null; // id du nœud ouvert
    let before = null;  // caméra avant l'ouverture (on y revient à la fermeture)
    let touched = false;

    const cam = createCamera({
      svg,
      world,
      bounds: WORLD,
      onMove: (c, tx, ty) => {
        starsG.setAttribute("transform", `translate(${(tx * 0.12).toFixed(1)} ${(ty * 0.12).toFixed(1)})`);
      },
      onUserMove: () => { touched = true; },
      onTap: (el) => {
        if (el) select(el.dataset.node);
        else if (current) closeSheet();
      },
    });

    const recId = sk.recommended;
    const recCam = () => {
      const p = pos[recId] || pos.hub;
      return { cx: p.x, cy: p.y + 40, k: 0.95 };
    };
    // Le panneau s'ouvre à droite : le nœud se place au milieu de la bande restée libre à gauche.
    const panelW = () => Math.min(cam.size().W * 0.72, 384);
    const focusCam = (id) => {
      const p = pos[id];
      const k = id === "hub" ? 0.8 : p.spine ? 1.05 : 1.1;
      return { cx: p.x + panelW() / 2 / k, cy: p.y, k };
    };

    // ----- ouverture de l'arbre (caméra) -----
    (async () => {
      if (reduced()) { cam.jumpTo(recCam()); return; }
      if (seen) {
        cam.jumpTo({ cx: geo.hub.x, cy: geo.hub.y - 260, k: 0.5 });
        await sleep(60);
        cam.flyTo(recCam(), { ms: 1000, arc: 0.12 });
        return;
      }
      cam.jumpTo({ cx: geo.hub.x, cy: geo.root.y - 120, k: 1.3 });
      if (!(await cam.flyTo({ cx: geo.hub.x, cy: geo.hub.y - 560, k: 0.4 }, { ms: 1400, ease: easeOut }))) return;
      await sleep(180);
      if (touched) return;
      cam.flyTo(recCam(), { ms: 1050, arc: 0.1 });
    })();

    // ----- sélection d'un nœud -----
    const els = new Map([...host.querySelectorAll("[data-node]")].map((e) => [e.dataset.node, e]));
    const edgeEls = [...host.querySelectorAll("[data-edge]")];
    const branchOf = (id) => (id === "hub" ? null : sk.byId[id].branch);

    function dim(id) {
      const br = id ? branchOf(id) : null;
      host.classList.toggle("has-focus", !!id);
      for (const [nid, el] of els) {
        const same = id && (nid === id || (br && branchOf(nid) === br) || nid === "hub");
        el.classList.toggle("is-focus", nid === id);
        el.classList.toggle("is-dim", !!id && !same);
      }
      for (const e of edgeEls) {
        const same = id && (!br || sk.byId[e.dataset.edge].branch === br);
        e.classList.toggle("is-dim", !!id && !same);
      }
    }

    function hubInfo() {
      const m = sk.me;
      return {
        id: "hub", title: "Toi", icon: "sparkles", kicker: m.levelName, state: "learning", progress: m.total,
        stat: `${pctText(m.total)} % de l'arbre éclairé · ${m.learned} mots vus`,
        blurb: "Ton niveau se juge sur tes résultats, pas sur le nombre de missions.",
        rule: "Ton niveau évolue avec tes résultats : test de niveau, quiz, jeux. Plus tu réussis, plus l'arbre s'éclaire.",
        missions: [
          { label: m.due ? `Revoir ${m.due} mot${m.due > 1 ? "s" : ""}` : "Apprendre de nouveaux mots", hint: m.due ? "mots qui reviennent" : "10 cartes", route: m.due ? "/vocabulaire/apprendre?mode=due" : "/vocabulaire/apprendre?mode=new", done: false },
          { label: "Refaire le test de niveau", hint: "2 minutes", route: "/placement", done: false },
        ],
      };
    }

    function sheetHTML(n) {
      const live = n.id === "hub" || n.live;
      const brLabel = n.id === "hub" ? n.kicker : `${sk.branches.find((b) => b.id === n.branch).label}${n.level ? ` · ${n.level}` : ""}`;
      const s = symbol(n.icon);
      const next = (n.missions || []).find((m) => !m.done) || (n.missions || [])[0];
      const cta = n.state === "mastered" ? "Rejouer" : n.state === "learning" ? "Continuer" : "Commencer";
      const rows = (n.missions || [])
        .map((m) => `<li><button type="button" class="tsheet__row${m.done ? " is-done" : ""}" data-route="${esc(m.route)}"><span class="tsheet__rn">${esc(m.label)}<small>${esc(m.hint || "")}</small></span><span class="tsheet__ri">${icon(m.done ? "check" : "arrowRight")}</span></button></li>`)
        .join("");
      const head = `
        <header class="tsheet__head">
          <span class="tsheet__chip"><svg viewBox="0 0 ${s.vb} ${s.vb}" fill="none" stroke="currentColor" stroke-width="${s.sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${s.body}</svg></span>
          <div><p class="tsheet__kicker">${esc(brLabel)}</p><h2 class="tsheet__title">${esc(n.title)}</h2></div>
          <button class="tsheet__x" type="button" aria-label="Fermer">×</button>
        </header>
        <p class="tsheet__blurb">${esc(n.blurb)}</p>`;
      if (!live) {
        return `${head}<p class="tsheet__soon">${icon("clock")}<span>Arrive bientôt. Rien n'est bloqué : le reste de l'arbre t'attend.</span></p>`;
      }
      return `${head}
        <div class="tsheet__prog">
          <p class="tsheet__pct"><b>${pctText(n.progress)}</b><span>%</span><em class="st-${n.state}">${STATE_TXT[n.state]}</em></p>
          <div class="tsheet__bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pctText(n.progress)}"><i style="--p:${pctText(n.progress)}"></i></div>
          <p class="tsheet__stat">${esc(n.stat)}</p>
        </div>
        ${n.rule ? `<h3 class="tsheet__h">Pour terminer</h3><p class="tsheet__rule">${esc(n.rule)}</p>` : ""}
        <h3 class="tsheet__h">Missions</h3>
        <ul class="tsheet__rows">${rows}</ul>
        ${next ? `<button class="tsheet__go" type="button" data-route="${esc(next.route)}"><span>${cta}</span>${icon("arrowRight")}</button>` : ""}`;
    }

    async function select(id) {
      if (!pos[id]) return;
      if (id === current) return;
      const info = id === "hub" ? hubInfo() : sk.byId[id];
      const wasOpen = !!current;
      if (!wasOpen) before = { ...cam.cam };
      current = id;
      dim(id);
      recBtn.classList.add("is-hidden");
      cam.flyTo(focusCam(id), { ms: wasOpen ? 800 : 850, arc: wasOpen ? 0.12 : 0.06 });
      if (wasOpen) {
        sheet.classList.add("is-swap");
        await sleep(200);
        if (current !== id) return;
      }
      sheet.innerHTML = sheetHTML(info);
      sheet.hidden = false;
      void sheet.offsetWidth;
      sheet.classList.remove("is-swap");
      requestAnimationFrame(() => sheet.classList.add("is-open"));
    }

    function closeSheet() {
      if (!current) return;
      current = null;
      dim(null);
      sheet.classList.remove("is-open");
      recBtn.classList.remove("is-hidden");
      setTimeout(() => { if (!current) sheet.hidden = true; }, 700);
      if (before) { cam.flyTo({ cx: before.cx, cy: before.cy, k: before.k * 0.92 }, { ms: 850, arc: 0 }); before = null; }
    }

    function launch(route) {
      const r = `${route}${route.includes("?") ? "&" : "?"}from=arbre`;
      openCard(sheet, `#${r}`, "game");
    }

    // ----- événements -----
    const onClick = (e) => {
      if (e.target.closest(".tsheet__x")) { closeSheet(); return; }
      const go = e.target.closest("[data-route]");
      if (go && sheet.contains(go)) { launch(go.dataset.route); return; }
      if (e.target.closest(".tree__rec")) { cam.flyTo(recCam(), { ms: 1000, arc: 0.12 }); return; }
      if (e.target.closest(".tree__back")) slideNavigate(host, "#/", "out");
    };
    const onKey = (e) => {
      if (e.key === "Escape" && current) { closeSheet(); return; }
      const n = e.target.closest?.("[data-node]");
      if (n && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); select(n.dataset.node); }
    };
    host.addEventListener("click", onClick);
    window.addEventListener("keydown", onKey);

    // glisser le panneau vers la droite pour le fermer
    let drag = null;
    const onSheetDown = (e) => {
      if (e.target.closest("button, a, .tsheet__rows")) return;
      drag = { x: e.clientX, y: e.clientY, dx: 0, on: false };
    };
    const onSheetMove = (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.on) {
        if (Math.abs(dx) < 10 || Math.abs(dx) < Math.abs(dy)) return;
        drag.on = true;
        sheet.style.transition = "none";
        sheet.setPointerCapture?.(e.pointerId);
      }
      drag.dx = Math.max(0, dx);
      sheet.style.transform = `translateX(${drag.dx}px)`;
    };
    const onSheetUp = () => {
      if (!drag) return;
      const { dx, on } = drag;
      drag = null;
      if (!on) return;
      sheet.style.transition = "";
      sheet.style.transform = "";
      if (dx > 70) closeSheet();
    };
    sheet.addEventListener("pointerdown", onSheetDown);
    sheet.addEventListener("pointermove", onSheetMove);
    sheet.addEventListener("pointerup", onSheetUp);
    sheet.addEventListener("pointercancel", onSheetUp);

    return () => {
      cam.destroy();
      host.removeEventListener("click", onClick);
      window.removeEventListener("keydown", onKey);
    };
  },
};
