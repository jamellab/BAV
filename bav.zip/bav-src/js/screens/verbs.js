// Jeu : verbes irréguliers (~100 verbes, data/irregular-verbs.json).
// Niveau 1 : on choisit le prétérit (passé simple). Niveau 2 : on choisit le participe passé.
// Niveau 3 : on tape le prétérit puis le participe passé.

import { esc, loadJSON } from "../data.js";
import { RANK, sample, norm, userCefr } from "../words.js";
import { gameScreen, runRounds, optionsHTML, bindOptions, mountTyping, speakBtn } from "../play.js";

const ROUNDS = 10;

// formes possibles pour un même verbe (« was/were »)
const forms = (s) => s.split("/").map((x) => norm(x));

export default gameScreen({
  path: "/jeux/verbes",
  title: "Verbes irréguliers",
  game: "verbs",
  async run(ctx) {
    const { verbs } = await loadJSON("irregular-verbs.json");
    const rank = RANK[userCefr()];
    let pool = verbs.filter((v) => RANK[v[4]] <= rank);
    if (pool.length < 25) pool = verbs.filter((v) => RANK[v[4]] <= Math.min(3, rank + 1));
    const items = sample(pool, ROUNDS);
    const col = ctx.d === 2 ? 2 : 1; // 1 = prétérit, 2 = participe

    const head = (v) => `<p class="slide__big slide__big--mod" lang="en">${esc(v[0])}</p><p class="slide__txt">${esc(v[3])}</p>`;
    const table = (v) => `<span lang="en"><b>${esc(v[0])}</b> · ${esc(v[1])} · ${esc(v[2])}</span>`;

    runRounds(ctx, items, (v) => {
      if (ctx.d <= 2) {
        const label = col === 1 ? "Prétérit (hier, I …)" : "Participe passé (I have …)";
        const right = v[col];
        const decoys = sample([...new Set(verbs.filter((x) => x[0] !== v[0]).flatMap((x) => [x[1], x[2]]))].filter((f) => f !== right && !right.includes(f)), 3);
        const options = sample([right, ...decoys], 4);
        return {
          body: `${head(v)}<p class="slide__small">${label}</p>${optionsHTML(options)}`,
          setup(api) { bindOptions(api, options.indexOf(right), `${speakBtn(`${v[0]}, ${v[1]}, ${v[2]}`, "Écouter")}${table(v)}`); },
        };
      }
      return {
        body: `${head(v)}<p class="slide__small" data-step>1/2 · Écris le prétérit</p><div class="typing-slot"></div>`,
        setup(api) {
          let step = 1;
          let first = "";
          const label = api.body.querySelector("[data-step]");
          const field = mountTyping(api, api.body.querySelector(".typing-slot"), {
            max: 14,
            onSubmit: (txt) => {
              if (step === 1) {
                first = txt;
                step = 2;
                field.set("");
                label.textContent = "2/2 · Écris le participe passé";
                return;
              }
              field.lock();
              const ok = forms(v[1]).includes(norm(first)) && forms(v[2]).includes(norm(txt));
              api.answer(ok, `${speakBtn(`${v[0]}, ${v[1]}, ${v[2]}`, "Écouter")}${table(v)}`);
            },
          });
        },
      };
    }, { tone: "deep" });
  },
});
