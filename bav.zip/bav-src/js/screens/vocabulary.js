// Écran « Vocabulaire » : cartes 3D en boucle (voir moduleDeck.js). Les missions sont les vraies flashcards et jeux de mots.

import { moduleScreen } from "./moduleDeck.js";

export default { path: "/vocabulaire", title: "Vocabulaire", layout: "stage", ...moduleScreen("vocabulaire") };
