// Le « cadre » de l'appli : barre du haut (logo = retour accueil, bouton couleurs). Plus de menu en bas : tout passe par les cartes.
// Le bouton couleurs ouvre un menu « Apparence » : palette, mode clair/sombre, son.

import { icon, swatchFan } from "./icons.js";
import { logoSVG } from "./brand.js";
import { esc } from "./data.js";
import { getTheme, setTheme, getPalette, setPalette, PALETTES } from "./theme.js";
import { soundEnabled, setSoundEnabled } from "./sound.js";
import { getName, setName } from "./profile.js";
import { userCefr, hasPlacement, LEVEL_NAMES } from "./words.js";

const MODES = [
  { id: "auto", label: "Auto", icon: "auto" },
  { id: "light", label: "Clair", icon: "sun" },
  { id: "dark", label: "Sombre", icon: "moon" },
];

export function mountShell(root, tabs) {
  const paletteOptions = PALETTES.map(
    (p) => `<button class="palette-option" type="button" data-palette-choice="${p.id}" aria-pressed="false">
      <span>${esc(p.name)}</span><span class="pal-dots" data-palette="${p.id}"><i></i><i></i><i></i><i></i><i></i></span></button>`
  ).join("");

  const modeButtons = MODES.map(
    (m) => `<button type="button" data-theme-choice="${m.id}" aria-pressed="false">${icon(m.icon)} ${m.label}</button>`
  ).join("");

  root.innerHTML = `
    <header class="topbar">
      <a class="topbar__brand" href="#/" aria-label="BAV, retour à l'accueil">${logoSVG()}</a>
      <button class="colors-btn" id="palette-btn" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="palette-menu">
        ${swatchFan()}<span>Couleurs</span>
      </button>
      <div class="palette-menu" id="palette-menu" role="dialog" aria-label="Apparence" hidden>
        <p class="palette-menu__title">Couleurs</p>
        ${paletteOptions}
        <p class="palette-menu__title">Mode</p>
        <div class="segmented segmented--full" id="mode-seg" role="group" aria-label="Mode clair ou sombre">${modeButtons}</div>
        <p class="palette-menu__title">Son</p>
        <button class="palette-option" type="button" id="sound-btn" aria-pressed="true"><span>Son d'entrée</span><span class="switch" aria-hidden="true"></span></button>
        <p class="palette-menu__title">Profil</p>
        <button class="palette-option" type="button" id="name-btn" aria-expanded="false"><span>Prénom</span><span class="palette-value" id="name-val"></span></button>
        <form class="name-form" id="name-form" hidden>
          <label class="sr-only" for="name-input">Ton prénom</label>
          <input id="name-input" name="prenom" type="text" maxlength="24" autocomplete="given-name" autocapitalize="words" enterkeyhint="done" placeholder="Ton prénom" required>
          <button class="btn btn--sm btn--accent" type="submit">OK</button>
        </form>
        <a class="palette-option" href="#/placement" id="level-link"><span>Refaire le test de niveau</span><span class="palette-value" id="level-val"></span></a>
      </div>
    </header>
    <main class="main" id="view" tabindex="-1"></main>
    <div class="toasts" id="toasts" role="status" aria-live="polite"></div>`;

  const pBtn = root.querySelector("#palette-btn");
  const menu = root.querySelector("#palette-menu");
  const paletteBtns = [...menu.querySelectorAll("[data-palette-choice]")];
  const modeBtns = [...menu.querySelectorAll("[data-theme-choice]")];
  const soundBtn = menu.querySelector("#sound-btn");

  const sync = () => {
    paletteBtns.forEach((o) => o.setAttribute("aria-pressed", String(o.dataset.paletteChoice === getPalette())));
    modeBtns.forEach((o) => o.setAttribute("aria-pressed", String(o.dataset.themeChoice === getTheme())));
    soundBtn.setAttribute("aria-pressed", String(soundEnabled()));
  };
  const closeMenu = () => { menu.hidden = true; pBtn.setAttribute("aria-expanded", "false"); };

  pBtn.addEventListener("click", () => {
    const opening = menu.hidden;
    menu.hidden = !opening;
    pBtn.setAttribute("aria-expanded", String(opening));
    if (opening) sync();
  });
  menu.addEventListener("click", (e) => {
    const pal = e.target.closest("[data-palette-choice]");
    const mode = e.target.closest("[data-theme-choice]");
    if (pal) setPalette(pal.dataset.paletteChoice);
    else if (mode) setTheme(mode.dataset.themeChoice);
    else if (e.target.closest("#sound-btn")) setSoundEnabled(!soundEnabled());
    sync();
  });
  document.addEventListener("click", (e) => {
    if (!menu.hidden && !e.target.closest("#palette-menu, #palette-btn")) closeMenu();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !menu.hidden) { closeMenu(); pBtn.focus(); }
  });
  window.addEventListener("themechange", sync);
  sync();

  // ----- Profil : changer son prénom, voir son niveau -----
  const nameBtn = menu.querySelector("#name-btn");
  const nameForm = menu.querySelector("#name-form");
  const nameInput = menu.querySelector("#name-input");
  const nameVal = menu.querySelector("#name-val");
  const levelVal = menu.querySelector("#level-val");
  const paintProfile = () => {
    nameVal.textContent = getName() || "—";
    levelVal.textContent = hasPlacement() ? LEVEL_NAMES[userCefr()].split(" · ")[1] : "à faire";
  };
  paintProfile();
  window.addEventListener("bav:name", paintProfile);
  window.addEventListener("bav:level", paintProfile);
  pBtn.addEventListener("click", paintProfile);
  nameBtn.addEventListener("click", () => {
    const open = nameForm.hidden;
    nameForm.hidden = !open;
    nameBtn.setAttribute("aria-expanded", String(open));
    if (open) { nameInput.value = getName(); nameInput.focus(); }
  });
  nameForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!setName(nameInput.value)) return;
    window.dispatchEvent(new Event("bav:name"));
    nameForm.hidden = true;
    nameBtn.setAttribute("aria-expanded", "false");
  });
  menu.querySelector("#level-link").addEventListener("click", closeMenu);

  // ----- Logo : petite animation au survol / au toucher (les barres de la voix « parlent ») -----
  const brand = root.querySelector(".topbar__brand");
  const wave = () => {
    brand.classList.remove("is-wave");
    void brand.offsetWidth;
    brand.classList.add("is-wave");
  };
  brand.addEventListener("pointerenter", wave);
  brand.addEventListener("pointerdown", wave);
}

/** Plus d'onglets : conservé pour le routeur, ne fait rien. */
export function highlightTab() {}
