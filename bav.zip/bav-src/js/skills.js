// Arbre des compétences : calcule, à partir de TES résultats, l'état de chaque nœud (à découvrir / en cours / maîtrisé).
// Aucun contenu n'est écrit ici : les nœuds viennent de data/skills.json, les mots de vocabulary.json, les résultats de localStorage.
//
// Ce qu'on enregistre en plus (storage.js, clé « skills ») :
//   games   : { idJeu: { runs, cleared: {1:true,2:true,3:false}, best: {1:0.9,…}, last } }   (niveau réussi = 70 % de bonnes réponses)
//   lessons : { idLeçon: { runs, done, best, last } }                                     (grammaire : leçon vue + meilleur quiz)
// Les flashcards n'ont rien de nouveau à stocker : l'état d'un nœud de vocabulaire vient des boîtes de Leitner (cards).

import { loadJSON } from "./data.js";
import { getData, update } from "./storage.js";
import { loadWords, userCefr, poolFor, RANK, LEVEL_NAMES } from "./words.js";
import { parisDate } from "./progress.js";
import { counts } from "./srs.js";

export const CLEAR_AT = 0.7; // part de bonnes réponses pour « réussir » un niveau de jeu
const LV = ["Facile", "Moyen", "Défi"];
const pct = (x) => `${Math.round(x * 100)} %`;

/** À appeler à la fin d'un jeu (play.js). */
export function recordGame(game, level, acc) {
  update((d) => {
    const g = (d.skills.games[game] ||= { runs: 0, cleared: {}, best: {}, last: "" });
    g.runs += 1;
    g.best[level] = Math.max(g.best[level] || 0, acc);
    if (acc >= CLEAR_AT) g.cleared[level] = true;
    g.last = parisDate();
  });
}

/** Grammaire : à appeler quand une leçon est lue (acc = null) ou qu'un quiz est terminé (acc = 0..1). */
export function recordLesson(id, acc = null) {
  update((d) => {
    const l = (d.skills.lessons[id] ||= { runs: 0, done: false, best: 0, last: "" });
    l.last = parisDate();
    if (acc == null) { l.done = true; return; }
    l.runs += 1;
    l.best = Math.max(l.best, acc);
  });
}

function stateOf(progress, started) {
  if (progress >= 0.8) return "mastered";
  return started ? "learning" : "discover";
}

function vocabNode(n, words, cards, today, cefr) {
  const list = words.filter((w) => w.cefr === n.level);
  const group = list.slice(Math.floor(list.length * n.from), Math.floor(list.length * n.to));
  let seen = 0, strong = 0, due = 0;
  for (const w of group) {
    const c = cards[w.id];
    if (!c) continue;
    seen++;
    if (c.b >= 3) strong++;
    if (c.due <= today) due++;
  }
  const progress = group.length ? Math.min(1, (seen * 0.35 + strong * 0.65) / group.length) : 0;
  const lv = `lv=${n.level}`;
  const unseen = group.length - seen;
  const weak = seen - strong;
  const rule = [
    "L'arbre s'éclaire quand tu vois les mots, puis que tu les retiens : un mot est « retenu » quand il atteint la boîte 3 de tes flashcards (réussi 2 fois).",
    unseen ? `Il te reste ${unseen} mot${unseen > 1 ? "s" : ""} à voir.` : "Tu as vu tous les mots.",
    weak ? `${weak} à mieux retenir.` : "",
  ].filter(Boolean).join(" ");
  return {
    rule,
    progress,
    state: stateOf(progress, seen > 0),
    stat: `${seen} mots vus sur ${group.length} · ${strong} bien retenus`,
    due,
    missions: [
      { label: "Nouveaux mots", hint: "10 cartes", route: `/vocabulaire/apprendre?mode=new&${lv}`, done: seen >= group.length },
      { label: "Mots à revoir", hint: due ? `${due} à revoir` : "rien pour l'instant", route: `/vocabulaire/apprendre?mode=due&${lv}`, done: seen > 0 && due === 0 },
      { label: "Phrases à trous", hint: "avec tes mots", route: "/jeux/phrases-a-trous?d=1", done: false },
    ],
  };
}

function gameNode(n, games) {
  const g = games[n.game] || { runs: 0, cleared: {}, best: {} };
  const done = [1, 2, 3].filter((d) => g.cleared[d]).length;
  const progress = done / 3 || (g.runs ? 0.08 : 0);
  const left = [1, 2, 3].filter((d) => !g.cleared[d]).map((d) => LV[d - 1]);
  return {
    rule: `Réussis les 3 niveaux, de Facile à Défi. Un niveau est réussi à partir de ${pct(CLEAR_AT)} de bonnes réponses.${left.length && left.length < 3 ? ` Il te reste : ${left.join(", ")}.` : ""}`,
    progress,
    state: done === 3 ? "mastered" : g.runs ? "learning" : "discover",
    stat: `${done} niveau${done > 1 ? "x" : ""} réussi${done > 1 ? "s" : ""} sur 3`,
    missions: [1, 2, 3].map((d) => ({
      label: LV[d - 1],
      hint: g.best[d] != null ? `meilleur : ${pct(g.best[d])}` : "pas encore joué",
      route: `${n.route}?d=${d}`,
      done: !!g.cleared[d],
    })),
  };
}

function lessonNode(n, lessons) {
  const l = lessons[n.id] || { runs: 0, done: false, best: 0 };
  const progress = Math.min(1, (l.done ? 0.35 : 0) + l.best * 0.65);
  return {
    rule: `Lis la mini-leçon (35 %), puis obtiens au moins ${pct(CLEAR_AT)} au quiz pour la maîtriser.`,
    progress,
    state: l.best >= CLEAR_AT ? "mastered" : l.done || l.runs ? "learning" : "discover",
    stat: l.runs ? `Meilleur quiz : ${pct(l.best)}` : l.done ? "Leçon lue, quiz à faire" : "Pas encore commencé",
    missions: [
      { label: "Mini-leçon", hint: "2 minutes", route: `/grammaire/lecon?id=${n.id}`, done: l.done },
      { label: "Quiz corrigé", hint: l.runs ? `meilleur : ${pct(l.best)}` : "avec explications", route: `/grammaire/quiz?id=${n.id}`, done: l.best >= CLEAR_AT },
    ],
  };
}

/** Construit l'arbre complet (nœuds + états + nœud recommandé + « toi »). */
export async function loadSkills() {
  const [def, words, gr] = await Promise.all([loadJSON("skills.json"), loadWords(), loadJSON("grammar.json")]);
  // les titres des leçons viennent de data/grammar.json (une seule source)
  const byId = Object.fromEntries(gr.lessons.map((l) => [l.id, l]));
  for (const b of def.branches) for (const n of b.nodes) if (n.kind === "lesson" && byId[n.id]) Object.assign(n, { title: byId[n.id].title, level: byId[n.id].level, blurb: byId[n.id].teaser });
  return build(def, words);
}

export function build(def, words) {
  const data = getData();
  const today = parisDate();
  const cefr = userCefr();
  const nodes = [];
  const branches = def.branches.map((b) => {
    const list = b.nodes.map((n) => {
      let extra;
      if (n.kind === "vocab") extra = vocabNode(n, words, data.cards, today, cefr);
      else if (n.kind === "game") extra = gameNode(n, data.skills.games);
      else if (n.kind === "lesson" && n.live !== false) extra = lessonNode(n, data.skills.lessons);
      else extra = { progress: 0, state: "soon", stat: "Arrive bientôt", missions: [] };
      return { ...n, branch: b.id, live: extra.state !== "soon", ...extra };
    });
    nodes.push(...list);
    const live = list.filter((n) => n.live);
    return { ...b, nodes: list, progress: live.length ? live.reduce((s, n) => s + n.progress, 0) / live.length : 0 };
  });

  // Nœud recommandé : d'abord ce qui est en cours (le moins avancé), sinon le premier nœud à découvrir à ton niveau
  const live = nodes.filter((n) => n.live && n.state !== "mastered");
  let recommended = live.filter((n) => n.state === "learning").sort((a, b) => a.progress - b.progress)[0];
  if (!recommended) {
    const order = ["vocabulaire", "grammaire", "jeux"];
    recommended = order
      .flatMap((id) => live.filter((n) => n.branch === id))
      .find((n) => (RANK[n.level] || 0) >= RANK[cefr] || !n.level);
    recommended ||= live[0];
  }

  const pool = poolFor(words, cefr);
  const c = counts(pool);
  const liveAll = nodes.filter((n) => n.live);
  const total = liveAll.length ? liveAll.reduce((s, n) => s + n.progress, 0) / liveAll.length : 0;

  return {
    def,
    branches,
    nodes,
    byId: Object.fromEntries(nodes.map((n) => [n.id, n])),
    recommended: recommended?.id || null,
    me: { cefr, levelName: LEVEL_NAMES[cefr], due: c.due, learned: c.learned, total },
  };
}
