// Transitions entre écrans.
//
// openCard(carte, adresse, cible) : la carte touchée GRANDIT (son texte s'efface) jusqu'à devenir l'écran suivant :
//   cible "game"  = la carte de jeu (même cadre que .play-card), cible "stage" = tout l'écran.
//   La carte agrandie reste posée par-dessus pendant le changement d'écran, puis se fond (finishMorph, appelé par le routeur).
// slideNavigate / slideArrive : pour « Retour » : l'écran glisse sur le côté, le précédent revient de l'autre côté.

const KEY = "bav:slide";
const reduced = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
const EASE = "cubic-bezier(.65, 0, .25, 1)";
export const MORPH_MS = 650;
export const SLIDE_MS = 420;

let morphEl = null;
let busy = false;

// ---------- Retour : glissement latéral ----------
export function slideNavigate(el, hash, dir = "in") {
  if (!el || reduced()) { location.hash = hash; return; }
  if (el.dataset.leaving) return;
  el.dataset.leaving = "1";
  el.classList.add(dir === "in" ? "is-to-right" : "is-to-left");
  setTimeout(() => {
    try { sessionStorage.setItem(KEY, dir === "in" ? "left" : "right"); } catch { /* rien */ }
    location.hash = hash;
  }, SLIDE_MS - 20);
}

export function slideArrive(el) {
  let side = null;
  try { side = sessionStorage.getItem(KEY); sessionStorage.removeItem(KEY); } catch { /* rien */ }
  if (!el || !side || reduced()) return;
  el.classList.add(`is-from-${side}`);
  void el.offsetWidth;
  el.classList.remove(`is-from-${side}`);
}

// ---------- Ouverture : la carte grandit ----------
function targetRect(kind) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const bar = document.querySelector(".topbar")?.getBoundingClientRect().bottom ?? 60;
  if (kind === "stage") return { left: 0, top: bar, width: vw, height: vh - bar, radius: 0 };
  // carte de jeu : même cadre que .play-card (38 rem max), sous la ligne « Retour »
  const width = Math.min(vw - 36, 608);
  const top = bar + 64;
  const height = Math.max(260, Math.min(576, vh - top - 16));
  return { left: (vw - width) / 2, top, width, height, radius: 8 };
}

export function openCard(card, hash, kind = "game") {
  if (!card || reduced() || busy) { location.hash = hash; return; }
  busy = true;
  const r = card.getBoundingClientRect();
  const m = card.cloneNode(true);
  m.classList.add("morph");
  m.removeAttribute("data-go"); m.removeAttribute("data-target"); m.removeAttribute("data-active");
  m.querySelector(".slide__veil")?.remove();
  m.setAttribute("aria-hidden", "true");
  Object.assign(m.style, {
    position: "fixed", inset: "auto", margin: "0", transform: "none", opacity: "1", zIndex: "2000",
    left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px`,
  });
  document.body.appendChild(m);
  morphEl = m;

  const t = targetRect(kind);
  const grow = m.animate(
    [
      { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px`, borderRadius: "8px" },
      { left: `${t.left}px`, top: `${t.top}px`, width: `${t.width}px`, height: `${t.height}px`, borderRadius: `${t.radius}px` },
    ],
    { duration: MORPH_MS, easing: EASE, fill: "forwards" }
  );
  // le texte de la carte s'efface pendant qu'elle s'ouvre
  [...m.children].forEach((k) =>
    k.animate([{ opacity: 1 }, { opacity: 1, offset: 0.18 }, { opacity: 0, offset: 0.55 }, { opacity: 0 }], { duration: MORPH_MS, fill: "forwards" })
  );
  const go = () => { busy = false; location.hash = hash; };
  grow.finished.then(go, go);
  setTimeout(finishMorph, MORPH_MS + 2500); // filet de sécurité si l'écran suivant ne s'affiche pas
}

/** Appelée par le routeur quand le nouvel écran est affiché : la carte agrandie se fond et disparaît. */
export function finishMorph() {
  const m = morphEl;
  if (!m) return;
  morphEl = null;
  const done = () => m.remove();
  m.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 380, delay: 60, easing: "ease-out", fill: "forwards" }).finished.then(done, done);
}
