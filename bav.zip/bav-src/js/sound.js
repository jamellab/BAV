// Sons de BAV, fabriqués directement dans le navigateur (Web Audio) : aucun fichier audio à charger.
// Les téléphones n'autorisent un son qu'après un toucher : on appelle donc playEnter() depuis le toucher
// de l'écran d'entrée (voir js/intro.js).

const KEY = "bav:sound";
let ctx = null;

export function soundEnabled() {
  try { return localStorage.getItem(KEY) !== "off"; } catch { return true; }
}

export function setSoundEnabled(on) {
  try { localStorage.setItem(KEY, on ? "on" : "off"); } catch { /* mode privé : on ignore */ }
}

function audio() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function tone(c, { freq, start, dur, type = "sine", gain = 0.12, glideTo }) {
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, start);
  if (glideTo) osc.frequency.exponentialRampToValueAtTime(glideTo, start + dur);
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(gain, start + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  osc.connect(g).connect(c.destination);
  osc.start(start);
  osc.stop(start + dur + 0.05);
}

/** Souffle qui accompagne les cartes quand elles se déploient. */
function whoosh(c, start, dur) {
  const len = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, len, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  const src = c.createBufferSource();
  src.buffer = buf;
  const filter = c.createBiquadFilter();
  filter.type = "bandpass";
  filter.Q.value = 0.9;
  filter.frequency.setValueAtTime(300, start);
  filter.frequency.exponentialRampToValueAtTime(2600, start + dur * 0.8);
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(0.07, start + dur * 0.35);
  g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  src.connect(filter).connect(g).connect(c.destination);
  src.start(start);
}

/** Le son d'entrée : bip de badge validé, souffle, puis petit arpège qui monte. */
export function playEnter() {
  if (!soundEnabled()) return;
  const c = audio();
  if (!c) return;
  const t = c.currentTime + 0.02;

  // « bip-bip » de badge
  tone(c, { freq: 988, start: t, dur: 0.09, type: "square", gain: 0.05 });
  tone(c, { freq: 1319, start: t + 0.1, dur: 0.14, type: "square", gain: 0.05 });

  // souffle des cartes
  whoosh(c, t + 0.12, 0.8);

  // arpège de bienvenue (do - mi - sol - do)
  [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) =>
    tone(c, { freq, start: t + 0.28 + i * 0.09, dur: 0.7, type: "triangle", gain: 0.11 })
  );
}
