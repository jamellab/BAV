// Répétition espacée : boîtes de Leitner (5 boîtes).
// Un mot réussi monte d'une boîte (il revient de plus en plus tard), un mot raté retombe en boîte 1.
// Boîte :            1    2    3    4     5
// Revient dans (j) : 0    1    3    7     14

import { getData, update } from "./storage.js";
import { parisDate, addDays } from "./progress.js";

const GAPS = [0, 0, 1, 3, 7, 14];

export const cardState = (id) => getData().cards[id] || null;

export function rate(id, ok) {
  const today = parisDate();
  update((d) => {
    const c = d.cards[id] || { b: 1, due: today, n: 0, ok: 0 };
    c.n += 1;
    if (ok) { c.ok += 1; c.b = Math.min(5, c.b + 1); } else { c.b = 1; }
    c.due = addDays(today, GAPS[c.b]);
    d.cards[id] = c;
  });
}

export function isDue(id) {
  const c = cardState(id);
  return !!c && c.due <= parisDate();
}

export function counts(words) {
  const today = parisDate();
  const cards = getData().cards;
  let due = 0, learned = 0, mastered = 0;
  for (const w of words) {
    const c = cards[w.id];
    if (!c) continue;
    learned++;
    if (c.b >= 4) mastered++;
    if (c.due <= today) due++;
  }
  return { due, learned, mastered, fresh: words.length - learned };
}

export function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Compose une session de `size` cartes : d'abord les mots à revoir (les plus en retard), puis des mots nouveaux.
 * Les mots nouveaux suivent l'ordre du niveau (A1 d'abord) mais sont mélangés par paquets, pour ne jamais
 * enchaîner des mots du même thème.
 */
export function pickSession(words, size = 10, { onlyDue = false } = {}) {
  const today = parisDate();
  const cards = getData().cards;
  const due = words
    .filter((w) => cards[w.id] && cards[w.id].due <= today)
    .sort((a, b) => cards[a.id].due.localeCompare(cards[b.id].due) || cards[a.id].b - cards[b.id].b);
  const picked = due.slice(0, size);
  if (!onlyDue && picked.length < size) {
    const fresh = words.filter((w) => !cards[w.id]);
    const batch = shuffle(fresh.slice(0, 60));
    picked.push(...batch.slice(0, size - picked.length));
  }
  return shuffle(picked);
}
