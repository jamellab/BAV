// Stockage de la progression : tout reste sur CE téléphone (localStorage), rien n'est envoyé.
// Un seul objet JSON, avec un numéro de version (« v ») pour pouvoir migrer plus tard sans rien perdre.
// Pour changer le format un jour : monter VERSION et ajouter une étape dans migrate().

const KEY = "bav:data";
const VERSION = 1;

const fresh = () => ({
  v: VERSION,
  profile: { cefr: null, placedAt: null },        // cefr : "A1" | "A2" | "B1" (niveau d'anglais, jugé sur les résultats)
  xp: { total: 0, weekKey: "", week: 0, best: 0 }, // XP totale, XP de la semaine (remise à zéro le lundi), record de semaine
  streak: { current: 0, best: 0, last: "" },       // série de jours
  days: [],                                        // derniers jours actifs (AAAA-MM-JJ)
  daily: { date: "", missions: 0, xp: 0, runs: {} },
  cards: {},                                       // flashcards : { idMot: { b: boîte 1-5, due: "AAAA-MM-JJ", n: vues, ok: réussites } }
  skills: { games: {}, lessons: {} },              // arbre des compétences : résultats par jeu (niveaux réussis) et par leçon de grammaire
  settings: { slow: false },
  last: null,                                      // dernière mission lancée : { route, title, module }
});

let cache = null;

function migrate(d) {
  const base = fresh();
  if (!d || typeof d !== "object") return base;
  // (exemple pour plus tard : if (d.v < 2) { …transformer… })
  const out = { ...base, ...d, v: VERSION };
  for (const k of Object.keys(base)) {
    if (base[k] && typeof base[k] === "object" && !Array.isArray(base[k])) out[k] = { ...base[k], ...(d[k] || {}) };
  }
  if (!Array.isArray(out.days)) out.days = [];
  return out;
}

function load() {
  try {
    return migrate(JSON.parse(localStorage.getItem(KEY) || "null"));
  } catch {
    return fresh();
  }
}

export function getData() {
  return (cache ??= load());
}

export function save() {
  try { localStorage.setItem(KEY, JSON.stringify(cache ?? load())); } catch { /* stockage plein ou bloqué : l'appli marche quand même */ }
}

/** Modifie les données puis sauvegarde et prévient l'interface. */
export function update(fn) {
  const d = getData();
  fn(d);
  save();
  window.dispatchEvent(new Event("bav:progress"));
  return d;
}

export function resetAll() {
  cache = fresh();
  save();
}
