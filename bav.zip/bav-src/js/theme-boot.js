// Petit script chargé AVANT l'affichage : applique le thème mémorisé tout de suite
// pour éviter un flash blanc en mode sombre. (Volontairement sans module.)
(function () {
  try {
    var t = localStorage.getItem("bav:theme");
    if (t === "light" || t === "dark") document.documentElement.setAttribute("data-theme", t);
    var p = localStorage.getItem("bav:palette");
    if (p === "ocre" || p === "lilas") document.documentElement.setAttribute("data-palette", p);
  } catch (e) {}
})();
