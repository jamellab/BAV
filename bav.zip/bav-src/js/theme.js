// Thème clair / sombre / automatique.
// "auto" = on suit le réglage du téléphone. Le choix est mémorisé dans localStorage.

const KEY = "bav:theme";
export const THEMES = ["auto", "light", "dark"];

export function getTheme() {
  try {
    const saved = localStorage.getItem(KEY);
    return THEMES.includes(saved) ? saved : "auto";
  } catch {
    return "auto";
  }
}

export function setTheme(theme) {
  try { localStorage.setItem(KEY, theme); } catch { /* mode privé : on ignore */ }
  applyTheme(theme);
  window.dispatchEvent(new CustomEvent("themechange", { detail: theme }));
}

export function cycleTheme() {
  const next = THEMES[(THEMES.indexOf(getTheme()) + 1) % THEMES.length];
  setTheme(next);
  return next;
}

// ---------- Palettes de couleurs ----------
// Les couleurs elles-mêmes sont dans css/tokens.css ([data-palette="…"]). Ici : la liste et le choix mémorisé.
const PKEY = "bav:palette";
export const PALETTES = [
  { id: "glacier", name: "Glacier" },
  { id: "ocre", name: "Ocre" },
  { id: "lilas", name: "Lilas" },
];

export function getPalette() {
  try {
    const saved = localStorage.getItem(PKEY);
    return PALETTES.some((p) => p.id === saved) ? saved : PALETTES[0].id;
  } catch {
    return PALETTES[0].id;
  }
}

export function setPalette(id) {
  try { localStorage.setItem(PKEY, id); } catch { /* mode privé : on ignore */ }
  applyPalette(id);
  window.dispatchEvent(new CustomEvent("palettechange", { detail: id }));
}

export function applyPalette(id = getPalette()) {
  const root = document.documentElement;
  if (id === PALETTES[0].id) root.removeAttribute("data-palette");
  else root.setAttribute("data-palette", id);
  syncStatusBarColor();
}

export function applyTheme(theme = getTheme()) {
  const root = document.documentElement;
  if (theme === "auto") root.removeAttribute("data-theme");
  else root.setAttribute("data-theme", theme);
  syncStatusBarColor();
}

/** Colore la barre d'état du navigateur mobile comme le fond de l'appli. */
export function syncStatusBarColor() {
  const probe = document.createElement("i");
  probe.style.color = "var(--bg)";
  document.body.append(probe);
  const color = getComputedStyle(probe).color;
  probe.remove();
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", color);
}

// Si le téléphone change de mode (jour/nuit) pendant que l'appli est ouverte
window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => syncStatusBarColor());
