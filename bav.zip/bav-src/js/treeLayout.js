// Géométrie de l'arbre : courbes de Bézier des branches, position des nœuds, chemins SVG.
// Fonctions pures (aucun accès à la page) : on peut les tester seules.

export const WORLD = { w: 1900, h: 2440 };

const rad = (d) => (d * Math.PI) / 180;
const lerp = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });

/** Courbe de Bézier cubique d'une branche : 4 points de contrôle, du centre (hub) vers l'extérieur. */
export function branchCurve(b, hub) {
  const th = rad(b.angle);
  const dir = { x: Math.sin(th), y: -Math.cos(th) };
  const perp = { x: Math.cos(th), y: Math.sin(th) };
  const bend = -Math.sign(b.angle || 0) * (b.curl || 0); // la branche se redresse vers le haut, comme un vrai arbre
  const sway = b.sway || 0;
  const at = (f, side) => ({ x: hub.x + dir.x * b.len * f + perp.x * side, y: hub.y + dir.y * b.len * f + perp.y * side });
  return [{ ...hub }, at(0.34, sway), at(0.7, bend * 0.55 - sway), at(1, bend)];
}

export function cubicAt(c, t) {
  const u = 1 - t;
  const w = [u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t];
  return { x: w[0] * c[0].x + w[1] * c[1].x + w[2] * c[2].x + w[3] * c[3].x, y: w[0] * c[0].y + w[1] * c[1].y + w[2] * c[2].y + w[3] * c[3].y };
}

export function cubicTangent(c, t) {
  const u = 1 - t;
  const x = 3 * u * u * (c[1].x - c[0].x) + 6 * u * t * (c[2].x - c[1].x) + 3 * t * t * (c[3].x - c[2].x);
  const y = 3 * u * u * (c[1].y - c[0].y) + 6 * u * t * (c[2].y - c[1].y) + 3 * t * t * (c[3].y - c[2].y);
  const l = Math.hypot(x, y) || 1;
  return { x: x / l, y: y / l };
}

/** Morceau de la courbe entre t0 et t1 (algorithme de de Casteljau). */
export function subCurve(c, t0, t1) {
  const split = (p, t) => {
    const a = lerp(p[0], p[1], t), b = lerp(p[1], p[2], t), d = lerp(p[2], p[3], t);
    const e = lerp(a, b, t), f = lerp(b, d, t), g = lerp(e, f, t);
    return [[p[0], a, e, g], [g, f, d, p[3]]];
  };
  const right = split(c, t0)[1];
  const k = t0 >= 1 ? 1 : (t1 - t0) / (1 - t0);
  return split(right, k)[0];
}

const f = (n) => n.toFixed(1);
export const cubicD = (c) => `M${f(c[0].x)} ${f(c[0].y)}C${f(c[1].x)} ${f(c[1].y)} ${f(c[2].x)} ${f(c[2].y)} ${f(c[3].x)} ${f(c[3].y)}`;

/**
 * Calcule tout l'arbre : { hub, root, branches: [{id, curve, nodes: [{id, x, y, r, spine, parent, d}]}], trunk }
 * - nœuds « spine » : posés sur la branche, reliés l'un à l'autre le long de la courbe
 * - nœuds latéraux (off ≠ 0) : posés à côté, reliés par un petit rameau au point de la branche.
 */
export function layout(def) {
  const hub = def.hub;
  const root = def.root;
  const trunk = `M${root.x} ${root.y}C${root.x - 26} ${root.y - 110} ${hub.x + 30} ${hub.y + 150} ${hub.x} ${hub.y}`;
  const pos = {};
  const branches = def.branches.map((b) => {
    const curve = branchCurve(b, hub);
    const spine = b.nodes.filter((n) => !n.off).sort((a, c) => a.t - c.t);
    const placed = [];
    let prevT = 0;
    let prevId = "hub";
    for (const n of spine) {
      const p = cubicAt(curve, n.t);
      placed.push({ id: n.id, x: p.x, y: p.y, r: 31, spine: true, parent: prevId, d: cubicD(subCurve(curve, prevT, n.t)), len: 0 });
      pos[n.id] = p;
      prevT = n.t;
      prevId = n.id;
    }
    for (const n of b.nodes.filter((n) => n.off)) {
      const base = cubicAt(curve, n.t);
      const tg = cubicTangent(curve, n.t);
      const nx = -tg.y, ny = tg.x; // normale
      const p = { x: base.x + nx * n.off, y: base.y + ny * n.off };
      const mid = { x: base.x + nx * n.off * 0.35 + tg.x * 26, y: base.y + ny * n.off * 0.35 + tg.y * 26 };
      const near = spine.filter((s) => s.t <= n.t).pop();
      placed.push({ id: n.id, x: p.x, y: p.y, r: 25, spine: false, parent: near ? near.id : "hub", d: `M${f(base.x)} ${f(base.y)}Q${f(mid.x)} ${f(mid.y)} ${f(p.x)} ${f(p.y)}` });
      pos[n.id] = p;
    }
    const tip = cubicAt(curve, 1);
    const tg = cubicTangent(curve, 1);
    return { id: b.id, curve, nodes: placed, tip, tangent: tg, mainD: cubicD(curve) };
  });
  return { hub, root, trunk, branches, pos };
}
