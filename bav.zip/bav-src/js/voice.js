// Voix : synthèse vocale du navigateur (Web Speech API). Choisit AUTOMATIQUEMENT la meilleure voix anglaise
// disponible (priorité aux voix « Natural », « Neural » ou Google), avec un mode lent et un bouton « réécouter ».
// La reconnaissance vocale (SpeechRecognition) servira au module Conversation (session 3).

import { getData, update } from "./storage.js";
import { toast } from "./components.js";

const synth = "speechSynthesis" in window ? window.speechSynthesis : null;
let voices = [];
let chosen = null;
let lastText = "";
let warned = false;

function score(v) {
  const n = `${v.name} ${v.voiceURI || ""}`.toLowerCase();
  const lang = (v.lang || "").replace("_", "-").toLowerCase();
  let s = 0;
  if (/natural|neural|online/.test(n)) s += 60;
  if (/google/.test(n)) s += 40;
  if (/premium|enhanced|siri|samantha|daniel|karen|serena|aaron|nicky/.test(n)) s += 25;
  if (lang === "en-us") s += 9;
  else if (lang === "en-gb") s += 7;
  else if (lang.startsWith("en-au") || lang.startsWith("en-ca") || lang.startsWith("en-ie")) s += 4;
  if (!v.localService) s += 2;
  if (/espeak|compact|novelty|bad news|bahh|bells|boing|bubbles|cellos|good news|jester|organ|superstar|trinoids|whisper|wobble|zarvox/.test(n)) s -= 80;
  return s;
}

function pick() {
  if (!synth) return;
  voices = synth.getVoices().filter((v) => (v.lang || "").toLowerCase().replace("_", "-").startsWith("en"));
  chosen = voices.slice().sort((a, b) => score(b) - score(a))[0] || null;
}

if (synth) {
  pick();
  synth.addEventListener?.("voiceschanged", pick); // sur beaucoup de téléphones, les voix arrivent un peu plus tard
}

export const voiceSupported = () => !!synth;
export const hasEnglishVoice = () => { pick(); return !!chosen; };
export const voiceName = () => chosen?.name || "";

export const isSlow = () => !!getData().settings.slow;
export const setSlow = (on) => update((d) => { d.settings.slow = !!on; });

const HELP =
  "Aucune voix anglaise trouvée sur ce téléphone. iPhone : Réglages > Accessibilité > Contenu énoncé > Voix > Anglais. " +
  "Android : Paramètres > Synthèse vocale > moteur Google > installer la voix anglaise.";

/** Lit un texte en anglais. À appeler pendant un toucher (obligatoire sur iPhone). */
export function speak(text, { slow = isSlow() } = {}) {
  if (!text) return Promise.resolve(false);
  lastText = text;
  if (!synth) {
    toast("Ce navigateur ne sait pas lire à voix haute. Essaie Chrome ou Safari.");
    return Promise.resolve(false);
  }
  pick();
  if (!chosen && !warned) {
    warned = true;
    toast(HELP);
  }
  return new Promise((resolve) => {
    try { synth.cancel(); } catch { /* rien */ }
    const u = new SpeechSynthesisUtterance(text);
    u.lang = chosen?.lang || "en-US";
    if (chosen) u.voice = chosen;
    u.rate = slow ? 0.62 : 0.95;
    u.pitch = 1;
    u.onend = () => resolve(true);
    u.onerror = () => resolve(false);
    synth.speak(u);
  });
}

export const replay = () => speak(lastText);
export const stopSpeaking = () => { try { synth?.cancel(); } catch { /* rien */ } };

/** Branche les boutons [data-speak="texte"], [data-replay] et [data-slow] d'une zone. Renvoie le nettoyage. */
export function bindVoice(root) {
  const onClick = (e) => {
    const s = e.target.closest("[data-speak]");
    const r = e.target.closest("[data-replay]");
    const sl = e.target.closest("[data-slow]");
    if (s) speak(s.dataset.speak);
    else if (r) replay();
    else if (sl) {
      setSlow(!isSlow());
      root.querySelectorAll("[data-slow]").forEach((b) => b.setAttribute("aria-pressed", String(isSlow())));
      toast(isSlow() ? "Mode lent : activé" : "Mode lent : désactivé");
    }
  };
  root.addEventListener("click", onClick);
  return () => { root.removeEventListener("click", onClick); stopSpeaking(); };
}
