// Vocabulaire : charge data/vocabulary.json (~1000 mots, chacun avec une phrase d'exemple) et prépare ce qu'il faut aux jeux.
// Format du fichier : { A1: [[en, fr, nature, phrase EN, phrase FR], …], A2: […], B1: […] }

import { loadJSON } from "./data.js";
import { getData } from "./storage.js";

export const RANK = { A1: 1, A2: 2, B1: 3 };
export const LEVEL_NAMES = { A1: "Débutant · A1", A2: "Intermédiaire · A2", B1: "Intermédiaire · B1" };

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
let all = null;

export async function loadWords() {
  if (all) return all;
  const j = await loadJSON("vocabulary.json");
  all = [];
  for (const cefr of ["A1", "A2", "B1"]) {
    for (const [en, fr, pos, ex, exFr] of j[cefr] || []) all.push({ id: `${slug(en)}.${pos}`, en, fr, pos, ex, exFr, cefr });
  }
  return all;
}

export const userCefr = () => getData().profile.cefr || "A1";
/** Débutant (A1) : traductions françaises visibles. Intermédiaire : anglais d'abord, traduction à la demande. */
export const isBeginner = () => userCefr() === "A1";
export const hasPlacement = () => !!getData().profile.cefr;

/** Mots accessibles au niveau de la personne (son niveau et en dessous). */
export function poolFor(words, cefr = userCefr()) {
  return words.filter((w) => RANK[w.cefr] <= RANK[cefr]);
}

/** Découpe la phrase d'un mot autour de ce mot : [avant, mot tel qu'écrit, après] (ou null). */
export function clozeParts(w) {
  const esc = w.en.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const m = new RegExp(`(^|[^A-Za-z])(${esc})(?![A-Za-z])`, "i").exec(w.ex);
  if (!m) return null;
  const start = m.index + m[1].length;
  return [w.ex.slice(0, start), w.ex.slice(start, start + w.en.length), w.ex.slice(start + w.en.length)];
}

/** Mot d'une seule suite de lettres (utilisable en mots croisés, dictée de mot…). */
export const isPlainWord = (w) => /^[a-z]+$/i.test(w.en);

/** Normalise un texte pour comparer une réponse tapée (casse, ponctuation, apostrophes). */
export function norm(s) {
  return String(s)
    .toLowerCase()
    .replace(/[’‘]/g, "'")
    .replace(/[^a-z0-9' ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export const sample = (arr, n) => {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, n);
};

/** Mot du jour : le même toute la journée, différent chaque jour. */
export function wordOfTheDay(words, dateStr) {
  const pool = poolFor(words).filter(isPlainWord);
  if (!pool.length) return null;
  let h = 0;
  for (const ch of dateStr) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return pool[h % pool.length];
}
